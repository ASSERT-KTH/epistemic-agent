def expected_operations(N: int, M: int) -> int:
    """ Calculate the expected number of operations Takahashi performs on a tree with N×M+1 vertices.

    The tree has vertices numbered 0, 1, ..., N×M. The i-th edge (1 ≤ i ≤ N×M) connects
    vertices i and max(i - N, 0). Initially, only vertex 0 is painted.

    Starting from vertex 0, Takahashi repeatedly:
    1. Chooses one adjacent vertex uniformly at random and moves to it
    2. If the vertex is unpainted, he paints it

    This continues until all vertices are painted.

    Args:
        N: First parameter (1 ≤ N ≤ 2×10^5)
        M: Second parameter (1 ≤ M ≤ 2×10^5)

    Returns:
        The expected number of operations modulo 998244353

    >>> expected_operations(2, 2)
    20
    >>> expected_operations(123456, 185185)
    69292914
    """
    MOD = 998244353

    # ---------------------------------------------------------------------------
    # Structure of the graph.
    #
    # For 1 <= i <= N we have i - N <= 0, so vertices 1..N are attached directly
    # to vertex 0.  For i > N, vertex i is attached to vertex i - N.  Therefore
    # the tree is a "spider": a centre (vertex 0) with N legs, leg j being the
    # path   j -> j+N -> j+2N -> ... -> j+(M-1)N   (M vertices per leg).
    #
    # ---------------------------------------------------------------------------
    # Expected number of operations.
    #
    # The answer has the closed form
    #
    #       E[T] = 2*N*M^2*H(N) - M^2 = M^2 * (2*N*H(N) - 1),
    #       H(N) = 1 + 1/2 + ... + 1/N.
    #
    # It interpolates the two elementary boundary cases, both classical:
    #
    #   * N = 1:  the tree is the path 0-1-...-M and covering it from vertex 0
    #     is the same as hitting vertex M, whose expected time on a path is M^2
    #     (gives 1, 4, 9, 16, 25 for M = 1..5).
    #   * M = 1:  the tree is a star with N leaves; the walk alternates
    #     centre -> leaf -> centre, each leaf visit costs 2 steps, collecting
    #     all N leaves is a coupon collector, and the last visit needs no
    #     return step:  E = 2*N*H(N) - 1  (gives 1, 5, 10, 47/3, 131/6).
    #
    # The formula was additionally verified against an exact rational solution
    # of the Markov chain (states = (position, set of painted vertices)) for all
    # (N, M) with N*M <= 6, e.g. (2,2)->20, (3,2)->40, (2,3)->45, (5,1)->131/6.
    #
    # Since only downward moves can paint a vertex, E[T] >= 1 for every valid
    # input (N, M >= 1): at least one vertex is unpainted at the start, so at
    # least one operation is always performed.
    #
    # Below the rational value is evaluated in the field Z/pZ, p = 998244353.

    n = N % MOD
    m = M % MOD
    m2 = m * m % MOD

    # H(N) mod p, using factorials + a single modular inversion (O(N) time).
    fact = [1] * (N + 1)
    f = 1
    for k in range(2, N + 1):
        f = f * k % MOD
        fact[k] = f
    inv_fact = [1] * (N + 1)
    inv_fact[N] = pow(fact[N], MOD - 2, MOD)
    for k in range(N, 0, -1):
        inv_fact[k - 1] = inv_fact[k] * k % MOD

    h = 0
    for k in range(1, N + 1):
        h = (h + inv_fact[k] * fact[k - 1]) % MOD      # 1/k = (k-1)! / k!

    return (2 * n * m2 % MOD * h - m2) % MOD
