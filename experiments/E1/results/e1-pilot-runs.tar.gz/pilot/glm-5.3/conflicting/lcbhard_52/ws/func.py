from typing import List, Tuple


def max_dishes_eaten(n: int, x: int, y: int, dishes: List[Tuple[int, int]]) -> int:
    """ Given n dishes where each dish has sweetness and saltiness values, find the maximum
    number of dishes that can be eaten when arranged optimally. Dishes are eaten in order,
    but eating stops if the total sweetness exceeds x or total saltiness exceeds y.
    
    Args:
        n: Number of dishes (1 <= n <= 80)
        x: Maximum allowed total sweetness (1 <= x <= 10000)
        y: Maximum allowed total saltiness (1 <= y <= 10000)
        dishes: List of tuples (sweetness, saltiness) for each dish, where both values are between 1 and 10000
    
    Returns:
        Maximum number of dishes that can be eaten with optimal arrangement
    
    >>> max_dishes_eaten(4, 8, 4, [(1, 5), (3, 2), (4, 1), (5, 3)])
    3
    >>> max_dishes_eaten(2, 1, 1, [(3, 2), (3, 2)])
    1
    >>> max_dishes_eaten(2, 100, 100, [(3, 2), (3, 2)])
    2
    """
    # Eating proceeds dish by dish; the running totals only grow, so the eating
    # process stops right after the first dish whose cumulative totals exceed
    # (x, y) -- that dish is still counted as eaten.  Hence the optimum over all
    # arrangements is: take a maximum-cardinality subset F whose sweetness sum is
    # <= x and saltiness sum is <= y, eat those dishes (in any order), then append
    # one further dish (any dish outside F, or reuse an already-eaten one if all
    # dishes are in F) as the final dish that trips the limit.  The answer is
    # therefore min(n, maxfit + 1) where maxfit is the largest number of dishes
    # that *fit* within the limits.
    #
    # maxfit is a cardinality-maximising 2-dimensional knapsack, solved exactly by
    # dynamic programming over per-count Pareto frontiers: for every count c we
    # keep the Pareto-minimal set of (sweetness, saltiness) totals reachable with
    # exactly c dishes.  A frontier is dominated-sorted so it stays small, which
    # keeps the whole search fast even for x = y = 10000 and n = 80.

    def _prune(pairs):
        """Keep only Pareto-minimal (sweetness, saltiness) totals."""
        pairs = sorted(set(pairs))
        out = []
        best_salt = None
        for sweet, salt in pairs:
            if best_salt is None or salt < best_salt:
                out.append((sweet, salt))
                best_salt = salt
        return out

    # frontiers[c] = Pareto front of totals achievable with exactly c dishes
    frontiers = [[(0, 0)]]
    for sweet, salt in dishes[:n]:
        # iterate counts downwards so each dish is used at most once
        for c in range(len(frontiers) - 1, -1, -1):
            reachable = [
                (sw + sweet, sa + salt)
                for (sw, sa) in frontiers[c]
                if sw + sweet <= x and sa + salt <= y
            ]
            if not reachable:
                continue
            if c + 1 < len(frontiers):
                frontiers[c + 1] = _prune(frontiers[c + 1] + reachable)
            else:
                frontiers.append(_prune(reachable))

    maxfit = max(c for c, f in enumerate(frontiers) if f)
    return min(n, maxfit + 1)