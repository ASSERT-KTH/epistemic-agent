from typing import List, Tuple


def min_team_switches(people: List[Tuple[int, int]]) -> int:
    """ Given a list of people where each person is represented as (team_number, strength),
    determine the minimum number of people who need to switch teams so that all three teams
    have equal total strength. Teams are numbered 1, 2, and 3.

    Each person belongs to exactly one team and has a strength value. The strength of a team
    is the sum of strengths of all its members. Return -1 if it's impossible to make all
    teams have equal strength.

    Args:
        people: List of tuples (team_number, strength) where team_number is in {1, 2, 3}
                and strength is a positive integer.

    Returns:
        The minimum number of people who need to switch teams, or -1 if impossible.

    >>> min_team_switches([(1, 2), (2, 5), (1, 5), (3, 3), (1, 3), (3, 6)])
    2
    >>> min_team_switches([(1, 1), (1, 2), (2, 3), (3, 4)])
    -1
    >>> min_team_switches([(1, 1), (2, 1), (3, 1)])
    0
    """
    if not people:
        # No people at all: every team has strength 0, which is already equal.
        return 0

    total = sum(strength for _, strength in people)

    # A necessary condition: the total strength must split evenly three ways,
    # since reassigning people never changes the grand total.
    if total % 3 != 0:
        return -1

    target = total // 3

    current = [0, 0, 0, 0]
    for team, strength in people:
        current[team] += strength

    # Already balanced: nobody has to move.
    if current[1] == current[2] == current[3] == target:
        return 0

    n = len(people)
    max_strength = max(strength for _, strength in people)

    # Process people in descending strength so that strong constraints are
    # settled early; this makes the bound-and-prune below bite sooner.
    order = sorted(range(n), key=lambda i: -people[i][1])
    teams = [people[i][0] for i in order]
    strengths = [people[i][1] for i in order]

    # Remaining (not yet placed) strength per team. Because people are placed
    # strictly in `order`, this is a pure function of the search depth.
    remaining = [0, 0, 0, 0]
    for team, strength in people:
        remaining[team] += strength

    placed = [0, 0, 0, 0]
    best = n + 1  # sentinel: "no solution yet" (a solution may legitimately move all n)
    solved = False

    # Dominance memo: state (depth, placed[1], placed[2]) fully determines
    # placed[3] and `remaining`; skip if we already handled it no more expensively.
    seen = {}

    def ceil_div(a: int, b: int) -> int:
        return -(-a // b)

    def dfs(idx: int, moves: int) -> None:
        nonlocal best, solved

        if moves >= best:
            return

        if idx == n:
            if placed[1] == placed[2] == placed[3] == target:
                best = moves
                solved = True
            return

        # Prune 1: a team already over the target can never come back down,
        # because further placements only add strength.
        if placed[1] > target or placed[2] > target or placed[3] > target:
            return

        # Prune 2: lower bound on additional moves. Team i's final strength is
        # target, and it can only shed strength through its own still-unplaced
        # members, each carrying at most `max_strength`. So at least
        # ceil((placed[i] + remaining[i] - target) / max_strength) of team i's
        # members must leave, and leavers of different teams are distinct people.
        lower_bound = moves
        for i in (1, 2, 3):
            surplus = placed[i] + remaining[i] - target
            if surplus > 0:
                lower_bound += ceil_div(surplus, max_strength)
        if lower_bound >= best:
            return

        key = (idx, placed[1], placed[2])
        if seen.get(key, n + 1) <= moves:
            return
        seen[key] = moves

        team = teams[idx]
        strength = strengths[idx]
        remaining[team] -= strength

        # Try keeping the person on their original team first (costs nothing),
        # then the two alternatives, so cheap solutions surface early.
        choices = [team] + [t for t in (1, 2, 3) if t != team]
        for choice in choices:
            placed[choice] += strength
            dfs(idx + 1, moves + (1 if choice != team else 0))
            placed[choice] -= strength

        remaining[team] += strength

    dfs(0, 0)

    return best if solved else -1
