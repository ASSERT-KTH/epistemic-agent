def count_paths(N: int, M: int, K: int, extra_edges: list) -> int:
    """ Count the number of ways to move exactly K times in a directed graph.

    The graph has N vertices numbered 1 to N with N+M edges:
    - Edges 1 to N form a cycle: vertex i connects to vertex i+1 (vertex N connects to vertex 1)
    - M additional edges are given in extra_edges as (source, destination) pairs

    Starting from vertex 1, count the number of distinct paths of exactly K moves.
    Return the count modulo 998244353.

    Algorithm:
        Between uses of the extra edges ("hops") a walk is forced around the
        cycle, so a walk is identified by the times at which it hops and by
        which hop it takes.  Decomposing a walk by its LAST hop: a walk of
        length K whose last hop is edge i taken at step s consists of a walk of
        length s-1 ending at X_i, the hop itself, and then K-s forced cycle
        moves (exactly one continuation).  Hence, with W(t, v) = number of
        length-t walks from vertex 1 ending at v,

            answer = 1 + sum_{s=1..K} sum_i W(s-1, X_i)
                   = 1 + sum_{t=0..K-1} sum_i W(t, X_i)

        where the "1" is the hop-free (pure cycle) walk.  W satisfies

            W(t, v) = [t == v-1 (mod N)]                              (pure cycle)
                      + sum_i sum_{m>=0} W(t-1-d(v,Y_i)-m*N, X_i)     (last hop = i)

        with d(v, y) = (v - y) mod N, because after hopping to Y_i the walk
        needs tau = d(v, Y_i) + m*N >= 0 cycle moves to reach v.

        Only the values W(t, x) at the (at most M) distinct hop sources are
        ever needed.  Grouping the hops by target y and writing
        w_y(u) = sum of W(u, X_i) over hops i with Y_i = y, the inner double
        sum becomes a residue-class prefix sum C_y(r) = sum_m w_y(r - m*N).
        All of them are kept in one length-N circular table F, folded
        incrementally: F[p] receives w_y(t) at p = (t - y) mod N.  Reading
        F[(t-1-x) mod N] at time t yields exactly sum_y C_y(t-1-d(x,y)) -- the
        fold is exact because the next unused element of each residue class is
        always at least t, i.e. beyond the values folded so far.

        Complexity: O(N + K * (#distinct sources + #hops + #distinct targets))
        time, O(N + M) memory.

    Args:
        N: Number of vertices (2 <= N <= 200000)
        M: Number of extra edges (0 <= M <= 50)
        K: Number of moves to make (1 <= K <= 200000)
        extra_edges: List of M tuples (X_i, Y_i) representing directed edges from X_i to Y_i

    Returns:
        The number of K-length paths starting from vertex 1, modulo 998244353

    >>> count_paths(6, 2, 5, [(1, 4), (2, 5)])
    5
    >>> count_paths(10, 0, 200000, [])
    1
    """
    MOD = 998244353
    if not extra_edges:
        # Only the deterministic walk around the cycle exists.
        return 1 % MOD

    # Work with 0-based residues: vertex v <-> v-1.
    mult = {}          # source residue -> number of hops leaving it
    groups = {}        # target residue -> {source residue: multiplicity}
    for X, Y in extra_edges:
        x = (X - 1) % N
        y = (Y - 1) % N
        mult[x] = mult.get(x, 0) + 1
        g = groups.get(y)
        if g is None:
            g = groups[y] = {}
        g[x] = g.get(x, 0) + 1

    xs = sorted(mult)                        # distinct source residues
    L = len(xs)
    pos_of = {x: i for i, x in enumerate(xs)}
    mults = [mult[x] for x in xs]
    offs = [(N - 1 - x) for x in xs]         # (t - 1 - x) mod N == (tr + offs) mod N

    # Per target residue: precomputed (source slot, multiplicity) pairs and the
    # scatter index (t - y) mod N == (tr + scat) mod N.
    gitems = []
    scat = []
    for y in sorted(groups):
        gitems.append([(pos_of[x], c) for x, c in sorted(groups[y].items())])
        scat.append(N - y)

    F = [0] * N          # circular table of residue-class prefix sums
    avals = [0] * L      # W(t, x) for the distinct sources
    total = 1 % MOD      # the hop-free walk
    tr = 0               # t mod N

    for _ in range(K):
        # W(t, x) = [t == x mod N] + F[(t-1-x) mod N]
        for i in range(L):
            idx = tr + offs[i]
            if idx >= N:
                idx -= N
            a = F[idx]
            if tr == xs[i]:
                a += 1
            avals[i] = a
        # walks whose last hop happens at step t+1
        acc = 0
        for i in range(L):
            acc += mults[i] * avals[i]
        total = (total + acc) % MOD
        # fold time-t values into the residue accumulators
        for gi in range(len(gitems)):
            v = 0
            for i, c in gitems[gi]:
                v += c * avals[i]
            if v:
                pos = tr + scat[gi]
                if pos >= N:
                    pos -= N
                F[pos] = (F[pos] + v) % MOD
        tr += 1
        if tr == N:
            tr = 0

    return total % MOD
