def count_good_strings(n: int, k: int, s: str) -> int:
    """ Given a string s of length n consisting of characters 'A', 'B', and '?',
    and a positive integer k, count the number of ways to replace each '?' with
    either 'A' or 'B' such that the resulting string has no palindromic substring
    of length k.

    A string is considered "good" if no contiguous substring of length k is a palindrome.
    Return the count modulo 998244353.

    Args:
        n: The length of the string (2 <= k <= n <= 1000)
        k: The length of substrings to check for palindromes (k <= 10)
        s: A string of length n consisting of 'A', 'B', and '?'

    Returns:
        The number of good strings modulo 998244353

    >>> count_good_strings(7, 4, 'AB?A?BA')
    1
    >>> count_good_strings(40, 7, '????????????????????????????????????????')
    116295436
    >>> count_good_strings(15, 5, 'ABABA??????????')
    0
    """
    MOD = 998244353

    # The parameter `n` is documented as len(s); trust the actual string, since
    # callers may pass a stale/incorrect value (see the unit tests, where n=1000
    # is supplied together with strings of length 977 and 777).
    n = len(s)
    if n == 0:
        return 1

    wildcards = sum(1 for c in s if c == '?')
    if k > n:
        # No substring of length k exists, so every filling is good.
        return pow(2, wildcards, MOD)

    # DP over the last (k-1) characters, encoded as an integer (msb = oldest).
    # dist[v] = number of valid prefixes whose last k-1 characters encode to v.
    states = 1 << (k - 1)
    mask = states - 1

    fixed = [None if c == '?' else (0 if c == 'A' else 1) for c in s]

    # Seed: all admissible assignments of the first k-1 characters.
    dist = [0] * states
    level_states = {()}
    for i in range(k - 1):
        opts = (0, 1) if fixed[i] is None else (fixed[i],)
        level_states = {t + (o,) for t in level_states for o in opts}
    for t in level_states:
        v = 0
        for bit in t:
            v = v * 2 + bit
        dist[v] = (dist[v] + 1) % MOD

    # Precompute which k-bit windows are palindromes.
    def is_palindrome(x: int) -> bool:
        bits = [(x >> i) & 1 for i in range(k - 1, -1, -1)]
        return bits == bits[::-1]

    palindrome = [is_palindrome(x) for x in range(1 << k)]

    for i in range(k - 1, n):
        nxt = [0] * states
        opts = (0, 1) if fixed[i] is None else (fixed[i],)
        for v, cnt in enumerate(dist):
            if not cnt:
                continue
            for o in opts:
                window = v * 2 + o  # the k characters ending at position i
                if palindrome[window]:
                    continue
                nxt[window & mask] = (nxt[window & mask] + cnt) % MOD
        dist = nxt
        if not any(dist):
            break

    return sum(dist) % MOD
