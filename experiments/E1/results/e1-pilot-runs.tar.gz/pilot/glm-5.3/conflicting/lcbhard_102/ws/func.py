from typing import List


def kth_alternating_permutation(n: int, k: int) -> List[int]:
    """ Given two integers n and k, return the k-th alternating permutation of the first n positive integers.

    An alternating permutation is a permutation where no two adjacent elements are both odd or both even.
    The permutations are sorted in lexicographical order.

    If there are fewer than k valid alternating permutations, return an empty list.

    Args:
        n: The number of elements in the permutation (1 <= n <= 100)
        k: The 1-indexed position of the desired permutation (1 <= k <= 10^15)

    Returns:
        The k-th alternating permutation, or an empty list if k is out of range

    >>> kth_alternating_permutation(4, 6)
    [3, 4, 1, 2]
    >>> kth_alternating_permutation(3, 2)
    [3, 2, 1]
    >>> kth_alternating_permutation(2, 3)
    []
    """
    if n < 1 or k < 1:
        return []

    # factorials[i] = i!
    factorials = [1] * (n + 1)
    for i in range(1, n + 1):
        factorials[i] = factorials[i - 1] * i

    def completions(remaining: int, o: int, e: int, next_parity: int) -> int:
        """Number of ways to fill the last `remaining` positions using the `o`
        unused odd and `e` unused even values, when the next position must hold a
        value of parity `next_parity` (1 = odd, 0 = even).

        Because consecutive values must alternate in parity, the parity of every
        remaining position is forced, so the count is o! * e! when the numbers of
        odd/even slots match, and 0 otherwise."""
        if next_parity == 1:
            odd_slots, even_slots = (remaining + 1) // 2, remaining // 2
        else:
            odd_slots, even_slots = remaining // 2, (remaining + 1) // 2
        if o == odd_slots and e == even_slots:
            return factorials[o] * factorials[e]
        return 0

    n_odd, n_even = (n + 1) // 2, n // 2

    # Total number of alternating permutations of 1..n.
    total = 0
    if n_odd > 0:
        total += n_odd * completions(n - 1, n_odd - 1, n_even, 0)
    if n_even > 0:
        total += n_even * completions(n - 1, n_odd, n_even - 1, 1)
    if k > total:
        return []

    result = []
    used = [False] * (n + 1)
    o_left, e_left = n_odd, n_even

    for i in range(n):
        prev_parity = -1 if i == 0 else (result[i - 1] & 1)
        for v in range(1, n + 1):
            if used[v] or (v & 1) == prev_parity:
                continue
            c = completions(n - i - 1, o_left - (v & 1), e_left - (1 - (v & 1)), 1 - (v & 1))
            if k > c:
                k -= c
                continue
            result.append(v)
            used[v] = True
            o_left -= v & 1
            e_left -= 1 - (v & 1)
            break

    return result
