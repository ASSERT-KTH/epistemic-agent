from typing import List, Tuple


def min_cost_to_achieve_goal(n: int, k: int, p: int, plans: List[Tuple[int, List[int]]]) -> int:
    """ 
    Given N development plans for a product with K parameters, find the minimum cost to raise
    all parameters to at least P. Each plan has a cost and increases parameters by specific amounts.
    Plans cannot be executed more than once.
    
    Args:
        n: Number of development plans (1 <= n <= 100)
        k: Number of parameters (1 <= k <= 5)
        p: Target value for all parameters (1 <= p <= 5)
        plans: List of tuples where each tuple contains:
               - cost: Cost of the plan (1 <= cost <= 10^9)
               - increases: List of K integers representing parameter increases (0 <= increase <= p)
    
    Returns:
        The minimum total cost to achieve the goal, or -1 if impossible.
    
    >>> min_cost_to_achieve_goal(4, 3, 5, [(5, [3, 0, 2]), (3, [1, 2, 3]), (3, [2, 4, 0]), (1, [0, 1, 4])])
    9
    >>> min_cost_to_achieve_goal(7, 3, 5, [(85, [1, 0, 1]), (37, [1, 1, 0]), (38, [2, 0, 0]), (45, [0, 2, 2]), (67, [1, 1, 0]), (12, [2, 2, 0]), (94, [2, 2, 1])])
    -1
    """
    INF = float('inf')
    # best[state] = min cost, where state encodes a base-(p+1) tuple of
    # per-parameter totals capped at p (anything >= p is already sufficient).
    size = (p + 1) ** k
    best = [INF] * size
    best[0] = 0

    def key_of(amounts):
        key = 0
        for a in amounts:
            key = key * (p + 1) + a
        return key

    for cost, increases in plans:
        inc = [min(v, p) for v in increases]
        new = best[:]  # "not executed": must copy so the plan is used at most once
        for state in range(size):
            cur = best[state]
            if cur == INF:
                continue
            digits = []
            ns = state
            for _ in range(k):
                digits.append(ns % (p + 1))
                ns //= (p + 1)
            digits.reverse()
            upd = []
            for j in range(k):
                upd.append(min(digits[j] + inc[j], p))
            ns_key = key_of(upd)
            cand = cur + cost
            if cand < new[ns_key]:
                new[ns_key] = cand
        best = new

    goal = size - 1  # all digits equal to p
    return best[goal] if best[goal] != INF else -1
