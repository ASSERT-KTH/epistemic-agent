def max_eleven_twentytwo_subsequence(s: str, l: int, r: int) -> int:
    """ Find the maximum length of a subsequence within s[l-1:r] that forms an 11/22 string.
    
    An 11/22 string is defined as:
    - It has odd length
    - The first (len+1)//2 - 1 characters are all '1'
    - The middle character at position (len+1)//2 is '/'
    - The remaining characters are all '2'
    
    For example: '/', '1/2', '11/22', '111/222' are 11/22 strings.
    
    Args:
        s: A string consisting of characters '1', '2', and '/'
        l: Starting position (1-indexed)
        r: Ending position (1-indexed, inclusive)
    
    Returns:
        The maximum length of a subsequence that forms an 11/22 string, or 0 if none exists.
    
    >>> max_eleven_twentytwo_subsequence('111/212', 1, 7)
    5
    >>> max_eleven_twentytwo_subsequence('111/212/1122', 9, 12)
    0
    >>> max_eleven_twentytwo_subsequence('111/212/1122', 3, 6)
    3
    """
    if r < l:
        return 0
    t = s[l - 1:r]

    # ones_before[i] = number of '1's in t[:i]; twos_after[i] = number of '2's in t[i+1:]
    n = len(t)
    ones_before = [0] * (n + 1)
    for i in range(n):
        ones_before[i + 1] = ones_before[i] + (1 if t[i] == '1' else 0)
    twos_after = [0] * (n + 1)
    for i in range(n - 1, -1, -1):
        twos_after[i] = twos_after[i + 1] + (1 if t[i] == '2' else 0)

    best_k = -1
    for i, ch in enumerate(t):
        if ch == '/':
            k = min(ones_before[i], twos_after[i + 1])
            if k > best_k:
                best_k = k
    return 2 * best_k + 1 if best_k >= 0 else 0