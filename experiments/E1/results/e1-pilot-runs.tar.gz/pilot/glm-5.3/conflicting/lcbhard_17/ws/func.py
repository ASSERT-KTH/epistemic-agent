MOD = 998244353

# factorials / inverse factorials for small indices (<= 6)
_FACT = [1]
for _i in range(1, 8):
    _FACT.append(_FACT[-1] * _i)
_INV_FACT = [pow(f, MOD - 2, MOD) for f in _FACT]


def _binom_big(t: int, j: int) -> int:
    """C(t, j) mod MOD for huge t (t reduced factor by factor), j small."""
    if j < 0 or t < j:
        return 0
    num = 1
    for i in range(j):
        num = num * ((t - i) % MOD) % MOD
    return num * _INV_FACT[j] % MOD


def sum_of_scores(n: int, m: int) -> int:
    """ Calculate the sum of scores of all good sequences modulo 998244353.

    A good sequence is an integer sequence of length between 1 and n (inclusive),
    where each element is between 1 and m (inclusive).

    The score of a good sequence is the number of positive divisors of X,
    where X is the product of all elements in the sequence.

    The function computes the sum of scores of all possible good sequences.
    There are sum(m^k for k in range(1, n+1)) such sequences in total.

    Args:
        n: Maximum length of sequences (1 <= n <= 10^18)
        m: Maximum value of elements (1 <= m <= 16)

    Returns:
        The sum of all scores modulo 998244353

    >>> sum_of_scores(1, 7)
    16
    >>> sum_of_scores(3, 11)
    16095
    >>> sum_of_scores(81131, 14)
    182955659
    """
    if m == 1:
        # every element is 1, product is 1, d(1) = 1 -> n sequences of each length
        return n % MOD

    # primes that can divide an element <= m
    primes = [p for p in (2, 3, 5, 7, 11, 13) if p <= m]
    k = len(primes)
    full = (1 << k) - 1

    # exponent vector of each element 1..m over `primes`
    vecs = []
    for a in range(1, m + 1):
        x = a
        v = []
        for p in primes:
            e = 0
            while x % p == 0:
                x //= p
                e += 1
            v.append(e)
        vecs.append(v)

    # w[R] = sum_{a=1..m} prod_{p in R} v_p(a)
    w = [0] * (1 << k)
    for R in range(1 << k):
        s = 0
        for v in vecs:
            prod = 1
            for i in range(k):
                if (R >> i) & 1:
                    prod *= v[i]
            s += prod
        w[R] = s

    # E[T][j] = sum over ordered j-tuples of disjoint non-empty prime subsets
    # with union exactly T, of prod over blocks of w[block].
    # Since blocks are ordered here, each unordered set partition is counted
    # j! times, which cancels the 1/j! in the divisor expansion below.
    E = [[0] * (k + 1) for _ in range(1 << k)]
    E[0][0] = 1
    for T in range(1 << k):
        B = T
        while B:  # blocks must be non-empty
            for j in range(k):
                if E[T ^ B][j]:
                    E[T][j + 1] = (E[T][j + 1] + E[T ^ B][j] * w[B]) % MOD
            B = (B - 1) & T
    # c[j] = sum over all ordered j-tuples of disjoint non-empty prime subsets
    # (their union may be any subset of the primes); c[0] = 1.
    c = [sum(E[T][j] for T in range(1 << k)) % MOD for j in range(k + 1)]

    x = m % MOD
    inv_one_minus_x = pow((1 - m) % MOD, MOD - 2, MOD)
    inv_x_minus_1 = pow((x - 1) % MOD, MOD - 2, MOD)
    inv_m = pow(x, MOD - 2, MOD)

    # table[j][i] = S_j(n - i) = sum_{t=0}^{n-i} C(t, j) * m^t  (mod MOD)
    # using  (1-x) S_j(N) = x * S_{j-1}(N-1) - C(N, j) * x^{N+1}
    table = [[0] * (k + 2) for _ in range(k + 1)]
    for i in range(k + 1):
        t = n - i
        if t >= 0:
            table[0][i] = (pow(x, t + 1, MOD) - 1) * inv_x_minus_1 % MOD
        else:
            table[0][i] = 0
    for j in range(1, k + 1):
        for i in range(k + 1):
            t = n - i
            if t < j:
                table[j][i] = 0
                continue
            table[j][i] = (
                x * table[j - 1][i + 1]
                - _binom_big(t, j) * pow(x, t + 1, MOD)
            ) * inv_one_minus_x % MOD

    # Fixed-length identity (verified against brute force):
    #   T_L = sum_{j} C(L, j) * m^(L-j) * c[j]
    # Summing over L = 1..n and using table[j][0] = sum_{t=0}^{n} C(t,j) m^t:
    #   total = ( sum_j c[j] * m^{-j} * S_j(n) ) - 1   (the -1 drops the L=0 term)
    ans = 0
    for j in range(k + 1):
        ans = (ans + c[j] * pow(inv_m, j, MOD) % MOD * table[j][0]) % MOD
    return (ans - 1) % MOD
