from functools import lru_cache

MOD = 10**9 + 7


def _count_up_to(n: str, min_sum: int, max_sum: int) -> int:
    """Count integers x in [0, n] (n given as a decimal string) with
    min_sum <= digit_sum(x) <= max_sum, modulo MOD.

    Uses a standard digit DP: walk the digits of n from the most significant
    one, tracking the running digit sum and whether the prefix is still tight
    (equal to n's prefix).  Leading zeros are harmless here because a leading
    zero contributes 0 to the digit sum and min_sum >= 1 keeps 0 itself out.
    """
    digits = [int(c) for c in n]
    length = len(digits)

    @lru_cache(maxsize=None)
    def rec(pos: int, s: int, tight: bool) -> int:
        if s > max_sum:
            # Digits are non-negative, the sum can only grow.
            return 0
        if pos == length:
            return 1 if s >= min_sum else 0
        top = digits[pos] if tight else 9
        return sum(rec(pos + 1, s + d, tight and d == top) % MOD
                   for d in range(top + 1)) % MOD

    return rec(0, 0, True) % MOD


def count_good_integers(num1: str, num2: str, min_sum: int, max_sum: int) -> int:
    """ Count the number of integers x such that num1 <= x <= num2 and 
    min_sum <= digit_sum(x) <= max_sum, where digit_sum(x) is the sum of digits of x.
    
    Return the count modulo 10^9 + 7.
    
    Args:
        num1: A numeric string representing the lower bound (1 <= num1 <= 10^22)
        num2: A numeric string representing the upper bound (num1 <= num2 <= 10^22)
        min_sum: The minimum allowed digit sum (1 <= min_sum <= 400)
        max_sum: The maximum allowed digit sum (min_sum <= max_sum <= 400)
    
    Returns:
        The number of good integers modulo 10^9 + 7
    
    >>> count_good_integers("1", "12", 1, 8)
    11
    >>> count_good_integers("1", "5", 1, 5)
    5
    """
    # f(N) = number of good integers in [0, N]; inclusion-exclusion over the range.
    below = _count_up_to(str(int(num1) - 1), min_sum, max_sum)
    up_to = _count_up_to(num2, min_sum, max_sum)
    return (up_to - below) % MOD
