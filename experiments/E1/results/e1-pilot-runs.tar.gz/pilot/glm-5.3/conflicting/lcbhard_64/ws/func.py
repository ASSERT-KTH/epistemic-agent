from typing import List, Tuple
from functools import lru_cache
from bisect import bisect_left
import sys


def card_game_winner(n: int, m: int, l: int, takahashi_cards: List[int], aoki_cards: List[int], table_cards: List[int]) -> str:
    """ Takahashi and Aoki play a card game. Initially, Takahashi has n cards, Aoki has m cards, 
    and there are l cards on the table. Starting with Takahashi, they take turns:
    - Play one card from hand to table
    - Optionally take one card from table that has a smaller number than the played card
    
    The player who cannot make a move loses. Both players play optimally.
    
    Args:
        n: Number of cards in Takahashi's hand
        m: Number of cards in Aoki's hand  
        l: Number of cards on the table
        takahashi_cards: List of card values in Takahashi's hand
        aoki_cards: List of card values in Aoki's hand
        table_cards: List of card values on the table
        
    Returns:
        "Takahashi" if Takahashi wins, "Aoki" if Aoki wins
        
    >>> card_game_winner(1, 1, 2, [2], [4], [1, 3])
    'Aoki'
    >>> card_game_winner(1, 1, 1, [11], [5], [10])
    'Takahashi'
    """
    # Only the relative order of the card values matters, so compress the
    # values to dense ranks 1..k.  Ties keep the same rank (a card may only
    # take a *strictly smaller* card).
    all_cards = list(takahashi_cards) + list(aoki_cards) + list(table_cards)
    distinct = sorted(set(all_cards))
    rank = {v: i + 1 for i, v in enumerate(distinct)}

    t_start = tuple(sorted(rank[v] for v in takahashi_cards))
    a_start = tuple(sorted(rank[v] for v in aoki_cards))
    tab_start = tuple(sorted(rank[v] for v in table_cards))

    def remove_one(sorted_tuple: Tuple[int, ...], value: int) -> Tuple[int, ...]:
        """Remove a single occurrence of `value` from a sorted tuple."""
        i = bisect_left(sorted_tuple, value)
        return sorted_tuple[:i] + sorted_tuple[i + 1:]

    # The game is finite: every move either grows the table by one card, or
    # keeps its size while replacing a table card with a strictly larger one,
    # so the table multiset strictly increases (element-wise, when both are
    # sorted in descending order and padded with zeros).  Hence no state can
    # repeat and plain backward induction is sound.
    sys.setrecursionlimit(max(10000, 1000 * (n + m + l + 1)))

    @lru_cache(maxsize=None)
    def current_player_wins(turn: int, t_hand: Tuple[int, ...], a_hand: Tuple[int, ...], table: Tuple[int, ...]) -> bool:
        """True iff the player to move (0 = Takahashi, 1 = Aoki) has a winning strategy."""
        hand = t_hand if turn == 0 else a_hand
        if not hand:
            return False  # cannot play a card -> loses

        other = a_hand if turn == 0 else t_hand
        next_turn = 1 - turn

        for i, c in enumerate(hand):
            if i > 0 and hand[i - 1] == c:
                continue  # identical value already tried (hands are sorted)

            rest = hand[:i] + hand[i + 1:]
            played_table = tuple(sorted(table + (c,)))

            # Cards that may be taken: strictly smaller than the played card.
            # Only the table *before* the play matters: the played card itself
            # is not smaller than itself.  Duplicate values are equivalent.
            takable = []
            prev = None
            for x in table:
                if x < c and x != prev:
                    takable.append(x)
                    prev = x

            # Option 1: play without taking.
            if turn == 0:
                if not current_player_wins(1, rest, other, played_table):
                    return True
                # Option 2: play, then take one smaller table card.
                for x in takable:
                    new_table = remove_one(played_table, x)
                    if not current_player_wins(1, tuple(sorted(rest + (x,))), other, new_table):
                        return True
            else:
                if not current_player_wins(0, other, rest, played_table):
                    return True
                for x in takable:
                    new_table = remove_one(played_table, x)
                    if not current_player_wins(0, other, tuple(sorted(rest + (x,))), new_table):
                        return True

        return False

    return "Takahashi" if current_player_wins(0, t_start, a_start, tab_start) else "Aoki"
