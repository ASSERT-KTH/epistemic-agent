from math import gcd
from typing import List


def count_subsequence_pairs(nums: List[int]) -> int:
    """ Find the number of pairs of non-empty subsequences (seq1, seq2) of nums that satisfy:
    1. The subsequences seq1 and seq2 are disjoint (no index of nums is common between them)
    2. The GCD of the elements of seq1 is equal to the GCD of the elements of seq2

    Return the total number of such pairs modulo 10^9 + 7.

    Args:
        nums: An integer array where 1 <= len(nums) <= 200 and 1 <= nums[i] <= 200

    Returns:
        The number of valid subsequence pairs modulo 10^9 + 7

    >>> count_subsequence_pairs([1, 2, 3, 4])
    10
    >>> count_subsequence_pairs([10, 20, 30])
    2
    >>> count_subsequence_pairs([1, 1, 1, 1])
    50
    """
    MOD = 10 ** 9 + 7
    V = max(nums)
    n = len(nums)

    # c[x] = number of elements of nums divisible by x
    c = [0] * (V + 1)
    for x in range(1, V + 1):
        c[x] = sum(1 for v in nums if v % x == 0)

    # Mobius function via linear sieve
    mu = [1] * (V + 1)
    is_composite = [False] * (V + 1)
    primes = []
    for i in range(2, V + 1):
        if not is_composite[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            if i * p > V:
                break
            is_composite[i * p] = True
            if i % p == 0:
                mu[i * p] = 0
                break
            mu[i * p] = -mu[i]

    # divisors of each value up to V
    divs = [[] for _ in range(V + 1)]
    for x in range(1, V + 1):
        for m in range(x, V + 1, x):
            divs[m].append(x)

    pow2 = [1] * (n + 1)
    pow3 = [1] * (n + 1)
    for i in range(1, n + 1):
        pow2[i] = pow2[i - 1] * 2 % MOD
        pow3[i] = pow3[i - 1] * 3 % MOD

    total = 0
    # answer = sum over ordered pairs of target gcds (d, e), non-empty A and B disjoint
    # with gcd(A) = d, gcd(B) = e and d == e, expanded with [gcd(A)=d] = sum_{g|d} mu(d/g)*[g|gcd(A)].
    for d in range(1, V + 1):
        if c[d] == 0:
            continue
        mu_d = {g: mu[d // g] for g in divs[d]}
        for e in range(1, V + 1):
            if c[e] == 0:
                continue
            g0 = gcd(d, e)
            w = 0
            for g in divs[g0]:
                w += mu_d[g] * mu[e // g]
            if w == 0:
                continue
            lcm = d // g0 * e
            c_l = c[lcm] if lcm <= V else 0  # elements divisible by both d and e
            # raw counts ordered disjoint (A, B), A non-empty with d|all, B non-empty with e|all:
            # element divisible by lcm: 3 choices (in A / in B / unused), by d only: 2, by e only: 2, by neither: 1
            raw = pow3[c_l] * pow2[c[d] - c_l] % MOD * pow2[c[e] - c_l] % MOD
            weight = (raw - pow2[c[d]] - pow2[c[e]] + 1) % MOD
            total = (total + w * weight) % MOD
    return total % MOD
