from typing import List


def sum_of_subsequence_powers(nums: List[int], k: int) -> int:
    """ Given an integer array nums and a positive integer k, calculate the sum of powers
    of all subsequences of nums. The power of a subsequence is defined as the number of
    its subsequences that sum to k.
    
    Return the sum modulo 10^9 + 7.
    
    Args:
        nums: List of integers where 1 <= len(nums) <= 100 and 1 <= nums[i] <= 10^4
        k: Target sum where 1 <= k <= 100
    
    Returns:
        The sum of powers of all subsequences modulo 10^9 + 7
    
    >>> sum_of_subsequence_powers([1, 2, 3], 3)
    6
    >>> sum_of_subsequence_powers([2, 3, 3], 5)
    4
    >>> sum_of_subsequence_powers([1, 2, 3], 7)
    0
    """
    MOD = 10 ** 9 + 7

    # Each pair (S, T) with T a subsequence of S and sum(T) == k contributes 1 to the
    # answer.  Grouping by T instead of by S: an index-subset T with sum(T) == k is a
    # subsequence of exactly 2 ** (n - |T|) subsequences S (each of the n - |T| indices
    # outside T may independently be included in S or not).  Hence
    #
    #     answer = sum over index-subsets T with sum(T) == k of 2 ** (n - |T|).
    #
    # That is a knapsack DP over sums 0..k where skipping an element multiplies the
    # accumulated weight by 2 (it becomes a "free" element that can extend S) and
    # taking an element consumes its value from the remaining budget.
    #
    # dp[s] = sum of 2 ** (used-outsides) over processed prefixes, for subsets summing
    # to exactly s.  O(len(nums) * k).
    dp = [0] * (k + 1)
    dp[0] = 1
    for x in nums:
        # Element x is not placed in T: every existing subset can be extended into a
        # new subsequence S in two ways per such element, i.e. weight doubles.
        nxt = [(2 * w) % MOD for w in dp]
        if x <= k:
            # Element x is placed in T: budget decreases by x, weight unchanged.
            for s in range(k, x - 1, -1):
                nxt[s] = (nxt[s] + dp[s - x]) % MOD
        dp = nxt

    return dp[k]
