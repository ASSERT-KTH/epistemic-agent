MOD = 998244353


def count_paths(W: int, H: int, L: int, R: int, D: int, U: int) -> int:
    """Count the number of possible paths in a 2D grid with specific constraints.

    A block exists at lattice point (x, y) if:
    - 0 <= x <= W and 0 <= y <= H
    - AND (x < L OR x > R OR y < D OR y > U)

    A path starts at any block and can move one unit in the positive x-direction
    or positive y-direction any number of times (including zero), but must always
    land on a block.

    Return the total number of possible paths modulo 998244353.

    Args:
        W: Maximum x-coordinate (0 <= L <= R <= W <= 10^6)
        H: Maximum y-coordinate (0 <= D <= U <= H <= 10^6)
        L, R: x-coordinate bounds for the "hole" in the grid
        D, U: y-coordinate bounds for the "hole" in the grid

    Returns:
        Number of possible paths modulo 998244353

    >>> count_paths(4, 3, 1, 2, 2, 3)
    192
    >>> count_paths(10, 12, 4, 6, 8, 11)
    4519189
    >>> count_paths(192, 25, 0, 2, 0, 9)
    675935675
    """
    # ------------------------------------------------------------------
    # Interpretation
    # --------------
    # A path is determined by (start block, end block, step sequence); the
    # number of steps may be zero.  For a block v define
    #     f(v) = 1 + f(v - e_x) + f(v - e_y)        (0 if v is not a block),
    # i.e. f(v) counts the paths ending at v (the empty path included), and
    # the answer is the sum of f(v) over all blocks.
    #
    # Closed form
    # -----------
    # For a *full* rectangle define, for offsets x, y >= 0,
    #     g(x, y) = # (start, path) pairs ending at relative offset (x, y)
    #             = C(x+y+2, x+1) - 1,
    #     G(m, n) = sum of g over a whole (m+1) x (n+1) rectangle
    #             = C(m+n+4, m+2) - (m+1)(n+1) - m - n - 4,
    #     RectG(x1,x2,y1,y2) = 2-D inclusion-exclusion of G over a rectangle.
    #
    # Every path that visits the hole [L,R] x [D,U] is removed by
    #   * subtracting the paths whose start lies inside the hole,
    #   * subtracting the paths whose end lies inside the hole,
    #   * adding back those with both endpoints inside,
    #   * and decomposing the remainder by the *first* point p of the path
    #     that lies inside the hole:  p is either the start itself (already
    #     handled), or the step into p arrives from the left (p is on the
    #     hole's left edge x = L) or from below (p is on the bottom edge y = D).
    # ------------------------------------------------------------------

    # factorial / inverse factorial tables (largest index used is W+H+4)
    n_max = W + H + 4
    fact = [1] * (n_max + 1)
    f = 1
    for i in range(1, n_max + 1):
        f = f * i % MOD
        fact[i] = f
    inv_fact = [1] * (n_max + 1)
    inv = pow(f, MOD - 2, MOD)
    inv_fact[n_max] = inv
    for i in range(n_max, 0, -1):
        inv = inv * i % MOD
        inv_fact[i - 1] = inv

    def binom(n, k):
        if k < 0 or k > n or n < 0:
            return 0
        return fact[n] * inv_fact[k] % MOD * inv_fact[n - k] % MOD

    def G(m, n):
        if m < 0 or n < 0:
            return 0
        return (binom(m + n + 4, m + 2) - (m + 1) * (n + 1) - m - n - 4) % MOD

    def RectG(x1, x2, y1, y2):
        if x1 > x2 or y1 > y2:
            return 0
        return (G(x2, y2) - G(x1 - 1, y2) - G(x2, y1 - 1) + G(x1 - 1, y1 - 1)) % MOD

    # start / end inside the hole (2-D inclusion-exclusion on both)
    base = (G(W, H)
            - RectG(W - R, W - L, H - U, H - D)
            - RectG(L, R, D, U)
            + G(R - L, U - D)) % MOD

    # first hole point entered by an x-step: p = (L, j), j in [D, U]
    #   prefixes  (ending at (L-1, j)):  S = C(L+j+1, L) - 1
    #   suffixes  (from (L, j) to the end): E = g(W-L, H-j) - g(R-L, U-j)
    t2a = 0
    if L > 0:
        invfL = inv_fact[L]
        invfWL = inv_fact[W - L + 1]
        invfRL = inv_fact[R - L + 1]
        for j in range(D, U + 1):
            s = fact[L + j + 1] * inv_fact[j + 1] % MOD * invfL - 1
            e = (fact[W + H - L - j + 2] * inv_fact[H - j + 1] % MOD * invfWL
                 - fact[R + U - L - j + 2] * inv_fact[U - j + 1] % MOD * invfRL) % MOD
            t2a = (t2a + s * e) % MOD

    # first hole point entered by a y-step: p = (i, D), i in [L, R]
    #   prefixes  (ending at (i, D-1)):  S = C(i+D+1, D) - 1
    #   suffixes  (from (i, D) to the end): E = g(W-i, H-D) - g(R-i, U-D)
    t2b = 0
    if D > 0:
        invfD = inv_fact[D]
        invfHD = inv_fact[H - D + 1]
        invfUD = inv_fact[U - D + 1]
        for i in range(L, R + 1):
            s = fact[i + D + 1] * inv_fact[i + 1] % MOD * invfD - 1
            e = (fact[W + H - i - D + 2] * inv_fact[W - i + 1] % MOD * invfHD
                 - fact[R + U - i - D + 2] * inv_fact[R - i + 1] % MOD * invfUD) % MOD
            t2b = (t2b + s * e) % MOD

    return (base - t2a - t2b) % MOD
