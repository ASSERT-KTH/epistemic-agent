def count_paths(H: int, W: int, K: int, grid: list[str]) -> int:
    """ Count the number of ways to make K moves on a grid starting from any empty cell.
    
    The grid has H rows and W columns. Each cell is either empty ('.') or blocked ('#').
    A path consists of K+1 cells (starting cell + K moves) where:
    - All cells in the path are empty
    - Consecutive cells are adjacent (up, down, left, or right)
    - No cell is visited more than once in the path
    
    Args:
        H: Number of rows (1 <= H <= 10)
        W: Number of columns (1 <= W <= 10)
        K: Number of moves (1 <= K <= 11)
        grid: List of H strings, each of length W, representing the grid
    
    Returns:
        The number of valid paths of length K+1
    
    >>> count_paths(2, 2, 2, ['.#', '..'])
    2
    >>> count_paths(2, 3, 1, ['.#.', '#.#'])
    0
    """
    blocked = [[grid[r][c] == '#' for c in range(W)] for r in range(H)]
    moves = ((1, 0), (-1, 0), (0, 1), (0, -1))
    total = 0

    def dfs(r: int, c: int, moves_left: int, visited: list[list[bool]]) -> None:
        nonlocal total
        if moves_left == 0:
            total += 1
            return
        for dr, dc in moves:
            nr, nc = r + dr, c + dc
            if 0 <= nr < H and 0 <= nc < W and not blocked[nr][nc] \
                    and not visited[nr][nc]:
                visited[nr][nc] = True
                dfs(nr, nc, moves_left - 1, visited)
                visited[nr][nc] = False

    for sr in range(H):
        for sc in range(W):
            if blocked[sr][sc]:
                continue
            visited = [[False] * W for _ in range(H)]
            visited[sr][sc] = True
            dfs(sr, sc, K, visited)

    return total
