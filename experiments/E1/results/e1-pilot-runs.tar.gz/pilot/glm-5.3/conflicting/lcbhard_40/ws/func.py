from typing import List, Tuple


def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def min_sensor_cost(n: int, sections: List[int], sensor1: Tuple[int, int, int], sensor2: Tuple[int, int, int]) -> int:
    """ Given N sections to monitor on a conveyor belt, find the minimum cost to monitor all sections using two types of sensors.
    
    Each section has a length in meters that needs to be monitored. There are two types of sensors available:
    - Type 1: Can monitor L1 meters, costs C1 per sensor, and you can use at most K1 sensors
    - Type 2: Can monitor L2 meters, costs C2 per sensor, and you can use at most K2 sensors
    
    Sensors can overlap and can monitor more than the required length. For example, to monitor a 5-meter section,
    you could use one 4-meter sensor and one 2-meter sensor (total coverage: 6 meters).
    
    Args:
        n: Number of sections to monitor (1 <= n <= 100)
        sections: List of section lengths D_i in meters (1 <= D_i <= 10^5)
        sensor1: Tuple (L1, C1, K1) - length, cost, and max count for type 1 sensors
        sensor2: Tuple (L2, C2, K2) - length, cost, and max count for type 2 sensors
        
    Returns:
        The minimum total cost to monitor all sections, or -1 if impossible.
        
    >>> min_sensor_cost(3, [3, 5, 10], (4, 3, 3), (2, 2, 6))
    17
    >>> min_sensor_cost(3, [3, 5, 10], (4, 3, 3), (2, 2, 3))
    -1
    >>> min_sensor_cost(2, [4, 8], (3, 1, 100), (4, 10000, 100))
    5
    """
    L1, C1, K1 = sensor1
    L2, C2, K2 = sensor2

    # Sections must be covered, but sensors may overlap, so for a section of
    # length d the pair (x, y) of type-1/type-2 sensors used on it is feasible
    # iff x * L1 + y * L2 >= d.  y is determined minimally as ceil((d - x*L1)/L2).
    secs = [int(d) for d in sections[:n]]

    # An upper bound on the total number of type-1 sensors that can ever help.
    cap = min(K1, sum(_ceil_div(d, L1) for d in secs))

    INF = float("inf")
    # dp[j] = minimum total number of type-2 sensors needed across the
    # sections processed so far, given that exactly j type-1 sensors are used.
    dp = [0] + [INF] * cap

    for d in secs:
        # Efficient frontier of (x, y): for every achievable type-2 count y,
        # the smallest type-1 count x that reaches it.  Larger pairs are
        # dominated: they use more sensors of both types for the same coverage.
        ymax = _ceil_div(d, L2)
        pts = [(0, ymax)]
        for t in range(ymax - 1, -1, -1):
            # y > K2 on a single section already busts the global K2 budget
            # (every other section needs y >= 0), so those t are pruned.
            if t > K2:
                continue
            x = max(0, _ceil_div(d - t * L2, L1))
            if x >= 1:
                pts.append((x, t))
        pts.sort()

        ndp = [INF] * (cap + 1)
        for j in range(cap + 1):
            dj = dp[j]
            if dj == INF:
                continue
            for x, y in pts:
                if j + x > cap:
                    break
                if dj + y < ndp[j + x]:
                    ndp[j + x] = dj + y
        dp = ndp

    best = INF
    for j in range(cap + 1):
        if dp[j] <= K2:
            cost = j * C1 + dp[j] * C2
            if cost < best:
                best = cost
    return -1 if best == INF else best