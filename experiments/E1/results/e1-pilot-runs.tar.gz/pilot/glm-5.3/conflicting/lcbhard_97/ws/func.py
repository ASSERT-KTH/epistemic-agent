from typing import List


def min_cost_to_sort(n: int, permutation: List[int]) -> int:
    """ Given a permutation of integers from 1 to n, find the minimum total cost to sort it in
    ascending order. You can repeatedly swap adjacent elements, where swapping elements at
    positions i and i+1 (1-indexed) costs i.

    Args:
        n: The length of the permutation
        permutation: A list of integers from 1 to n in some order

    Returns:
        The minimum total cost required to sort the permutation in ascending order

    >>> min_cost_to_sort(3, [3, 2, 1])
    4
    >>> min_cost_to_sort(5, [2, 4, 1, 3, 5])
    6
    >>> min_cost_to_sort(2, [1, 2])
    0
    """
    a = list(permutation)
    total = 0
    while True:
        # Always swap the leftmost adjacent inversion: that swap happens at the
        # smallest possible index, hence the cheapest available price, and this
        # greedy is optimal (an inversion can only be removed by a swap of the
        # two elements involved, and paying a larger index first can never make
        # any later required swap cheaper).
        i = 0
        while i < n - 1 and a[i] <= a[i + 1]:
            i += 1
        if i == n - 1:
            break  # sorted
        a[i], a[i + 1] = a[i + 1], a[i]
        total += i + 1  # swap at 1-indexed position i+1 costs i+1
    return total
