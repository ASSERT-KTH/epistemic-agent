def matrix_with_k_fixed_elements_exists(n: int, k: int) -> bool:
    """ Given an integer n (size of matrix) and k (number of fixed elements),
    determine if there exists an n×n binary matrix with exactly k fixed elements.

    A binary matrix has elements that are either 0 or 1.
    Two matrices A and B are similar if they have the same row sums and column sums.
    An element at position (i,j) in matrix A is fixed if it has the same value
    in all matrices similar to A.

    Args:
        n: Size of the matrix (2 ≤ n ≤ 30)
        k: Number of fixed elements (0 ≤ k ≤ n²)

    Returns:
        True if there exists an n×n binary matrix with exactly k fixed elements,
        False otherwise.

    >>> matrix_with_k_fixed_elements_exists(3, 0)
    True
    >>> matrix_with_k_fixed_elements_exists(3, 9)
    True
    >>> matrix_with_k_fixed_elements_exists(3, 7)
    False

    Implementation notes
    --------------------
    Let N(A) be the set of *non-fixed* positions of A; the answer only depends on
    q = n² - k = |N(A)|.

    1. The matrices similar to A are exactly those reachable from A by 2x2
       interchanges (Ryser), so a position is not fixed iff it lies on a closed
       alternating walk in the bipartite "row–column" graph of A. From that
       characterization one obtains:  N(A) is a disjoint union of sub-boards
       R_1×C_1, ..., R_m×C_m with pairwise disjoint row sets R_t (|R_t| ≥ 2) and
       pairwise disjoint column sets C_t (|C_t| ≥ 2).  Consequently

           q = Σ_t a_t·b_t,   a_t, b_t ≥ 2,   Σ a_t ≤ n,   Σ b_t ≤ n.   (*)

       (Neither a nor b can be 1: a single row/column inside a block could be
       switched only together with other rows/columns, and a 1×b strip is rigid.)

    2. Conversely every configuration (*) is realizable: arrange the blocks along
       the diagonal, each filled with an a_t×b_t pattern that has no fixed
       positions of its own (one 1 per column spread over all rows when a_t ≤ b_t,
       the transpose otherwise); make the cross positions (row of block t,
       column of block s) equal to 1 for t < s and 0 for t > s; unused rows are
       all-0 rows and unused columns all-0 columns.  Each position inside a block
       is non-fixed (a switch inside the block), and each position outside all
       blocks is fixed.

    Hence a matrix with exactly k fixed elements exists iff q = n² - k admits a
    representation (*).  This is decided by a subset-sum DP over the remaining
    row budget r and column budget c:

        dp[r][c] = bitmask whose s-th bit is 1 iff s is representable

    and the answer is the q-th bit of dp[n][n].
    """
    total_cells = n * n
    q = total_cells - k
    if q < 0 or q > total_cells:
        return False
    if q == 0:
        return True

    mask_all = (1 << (total_cells + 1)) - 1

    # dp[r][c]: bitmask of sums representable with r rows and c columns of budget.
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    # Process states by increasing total budget so each state is complete
    # before it is read by a larger one.  q = 0 (no block) is always possible.
    for budget in range(2 * n + 1):
        for r in range(max(0, budget - n), min(n, budget) + 1):
            c = budget - r
            acc = 1  # the empty configuration
            for a in range(2, r + 1):
                rest_rows = dp[r - a]
                for b in range(2, c + 1):
                    acc |= rest_rows[c - b] << (a * b)
            dp[r][c] = acc & mask_all

    return (dp[n][n] >> q) & 1 == 1
