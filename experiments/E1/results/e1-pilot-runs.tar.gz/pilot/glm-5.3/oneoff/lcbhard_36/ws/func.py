from typing import List


def min_operations_to_sum(nums: List[int], target: int) -> int:
    """ Given a list of non-negative powers of 2 and a target sum, find the minimum number
    of operations needed to create a subsequence that sums to the target.

    In one operation, you can:
    - Choose any element nums[i] where nums[i] > 1
    - Remove nums[i] from the array
    - Add two occurrences of nums[i] // 2 to the end of the array

    Return the minimum number of operations needed, or -1 if impossible.

    Args:
        nums: List of integers that are powers of 2 (1 <= len(nums) <= 1000)
        target: Target sum to achieve (1 <= target < 2^31)

    Returns:
        Minimum number of operations, or -1 if impossible

    >>> min_operations_to_sum([1, 2, 8], 7)
    1
    >>> min_operations_to_sum([1, 32, 1, 2], 12)
    2
    >>> min_operations_to_sum([1, 32, 1], 35)
    -1
    """
    if target == 0:
        return 0

    # Splitting preserves the total sum, so anything above the total is unreachable,
    # and everything at or below it is reachable (split everything down to 1s).
    total = sum(nums)
    if total < target:
        return -1

    max_bit = max(max(nums).bit_length(), target.bit_length())
    # cnt[i] = how many pieces of value 2**i are currently available.
    cnt = [0] * (max_bit + 2)
    for x in nums:
        cnt[x.bit_length() - 1] += 1

    ops = 0
    for i in range(target.bit_length()):
        if (target >> i) & 1:
            if cnt[i] == 0:
                # No piece of exactly 2**i: take the nearest larger piece and split it
                # down along a single chain.  Turning 2**j into one 2**i costs (j - i)
                # operations and leaves one spare piece at every level i..j-1
                # (plus a second spare 2**i).
                j = i + 1
                while cnt[j] == 0:
                    j += 1
                cnt[j] -= 1
                for k in range(i, j):
                    cnt[k] += 1
                cnt[i] += 1
                ops += j - i
            cnt[i] -= 1
        # Two unused 2**i pieces can jointly stand in for one 2**(i+1) unit of the
        # target, since a subsequence only has to add up, not be a single element.
        cnt[i + 1] += cnt[i] // 2
        cnt[i] %= 2
    return ops
