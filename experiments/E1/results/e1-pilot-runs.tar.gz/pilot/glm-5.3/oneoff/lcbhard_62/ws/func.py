def count_paths(H: int, W: int, K: int, grid: list[str]) -> int:
    """ Count the number of ways to make K moves on a grid starting from any empty cell.

    The grid has H rows and W columns. Each cell is either empty ('.') or blocked ('#').
    A path consists of K+1 cells (starting cell + K moves) where:
    - All cells in the path are empty
    - Consecutive cells are adjacent (up, down, left, or right)
    - No cell is visited more than once in the path

    Args:
        H: Number of rows (1 <= H <= 10)
        W: Number of columns (1 <= W <= 10)
        K: Number of moves (1 <= K <= 11)
        grid: List of H strings, each of length W, representing the grid

    Returns:
        The number of valid paths of length K+1

    >>> count_paths(2, 2, 2, ['.#', '..'])
    2
    >>> count_paths(2, 3, 1, ['.#.', '#.#'])
    0
    """
    if K <= 0:
        return 0

    # Pre-compute, for every empty cell, the list of adjacent empty cells.
    neighbours = {}
    for r in range(H):
        for c in range(W):
            if grid[r][c] != '.':
                continue
            adj = []
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nr, nc = r + dr, c + dc
                if 0 <= nr < H and 0 <= nc < W and grid[nr][nc] == '.':
                    adj.append(nr * W + nc)
            neighbours[r * W + c] = adj

    def dfs(cell: int, visited: int, moves_left: int) -> int:
        """Count continuations of the current path using exactly `moves_left` more moves."""
        if moves_left == 0:
            return 1
        total = 0
        for nxt in neighbours[cell]:
            bit = 1 << nxt
            if not visited & bit:
                total += dfs(nxt, visited | bit, moves_left - 1)
        return total

    # Depth-first search from every empty cell, tracking visited cells in a bitmask.
    total = 0
    for start in neighbours:
        total += dfs(start, 1 << start, K)
    return total
