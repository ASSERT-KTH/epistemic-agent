import itertools, sys
from collections import defaultdict

def brute(n):
    n2 = n*n
    classes = defaultdict(lambda: [(1 << n2) - 1, 0])  # [AND, OR]
    for bits in range(1 << n2):
        r = []
        c = [0]*n
        for i in range(n):
            ri = 0
            for j in range(n):
                b = (bits >> (i*n+j)) & 1
                ri += b
                c[j] += b
            r.append(ri)
        key = (tuple(r), tuple(c))
        e = classes[key]
        e[0] &= bits
        e[1] |= bits
    ks = set()
    for key,(a,o) in classes.items():
        same = (a & o) | ((~a & ~o) & ((1 << n2) - 1))
        ks.add(bin(same).count('1'))
    return ks

if __name__ == "__main__":
    for n in (2,3,4):
        ks = brute(n)
        allk = set(range(n*n+1))
        print("n=%d  n^2=%d" % (n, n*n))
        print("   achievable:", sorted(ks))
        print("   impossible:", sorted(allk - ks))
        sys.stdout.flush()
