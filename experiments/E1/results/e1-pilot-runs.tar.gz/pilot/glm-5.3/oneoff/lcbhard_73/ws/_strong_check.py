import itertools

def f_scc_strong(A, r, q):
    """is the bipartite tournament on r rows, q cols (A[r][q], 1 = arc row->col) strongly connected?"""
    V=r+q
    adj=[[] for _ in range(V)]
    for i in range(r):
        for j in range(q):
            if A[i][j]: adj[i].append(r+j)
            else: adj[r+j].append(i)
    seen=[False]*V
    def bfs(src):
        seen[:]=[False]*V; seen[src]=True; dq=[src]
        while dq:
            u=dq.pop()
            for w in adj[u]:
                if not seen[w]: seen[w]=True; dq.append(w)
        return all(seen)
    return all(bfs(s) for s in range(V))

print("strong bipartite tournaments on r x q (small):")
for r in range(1,5):
    for q in range(1,5):
        found=False
        for bits in itertools.product([0,1],repeat=r*q):
            A=[list(bits[i*q:(i+1)*q]) for i in range(r)]
            if f_scc_strong(A,r,q): found=True; break
        print("  r=%d q=%d strong exists: %s"%(r,q,found))
