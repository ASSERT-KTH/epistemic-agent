import sys
from functools import lru_cache

def f_scc(A, n):
    V = 2*n
    adj=[[] for _ in range(V)]
    for i in range(n):
        Ai=A[i]
        for j in range(n):
            if Ai[j]: adj[i].append(n+j)
            else: adj[n+j].append(i)
    index=[-1]*V; low=[0]*V; onstk=[False]*V
    stk=[]; comp=[-1]*V; cnt=[0]; nc=[0]
    for s in range(V):
        if index[s]!=-1: continue
        work=[(s,0)]
        while work:
            v,pi=work[-1]
            if pi==0:
                index[v]=low[v]=cnt[0]; cnt[0]+=1
                stk.append(v); onstk[v]=True
            rec=False
            while pi<len(adj[v]):
                w=adj[v][pi]; pi+=1
                if index[w]==-1:
                    work[-1]=(v,pi); work.append((w,0)); rec=True; break
                elif onstk[w]: low[v]=min(low[v],index[w])
            if rec: continue
            work[-1]=(v,pi)
            if pi>=len(adj[v]):
                work.pop()
                if low[v]==index[v]:
                    while True:
                        w=stk.pop(); onstk[w]=False; comp[w]=nc[0]
                        if w==v: break
                    nc[0]+=1
                if work:
                    u,_=work[-1]; low[u]=min(low[u],low[v])
    size=[0]*nc[0]
    for v in range(V): size[comp[v]]+=1
    k=0
    for i in range(n):
        for j in range(n):
            if comp[i]!=comp[n+j]: k+=1
    return k

def partitions(n, maxpart, maxLen):
    # all nonincreasing tuples of length <= maxLen with parts <= maxpart summing to n
    res=[]
    def rec(rem, maxp, cur):
        if rem==0:
            res.append(tuple(cur)); return
        if len(cur)==maxLen: return
        for p in range(min(maxp,rem),0,-1):
            cur.append(p); rec(rem-p,p,cur); cur.pop()
    rec(n,maxpart,[])
    return res

def build(r, c, n):
    """bipartite Havel-Hakimi; return matrix or None. r,c are padded to length n."""
    r=list(r)+[0]*(n-len(r))
    c=list(c)+[0]*(n-len(c))
    if len(r)!=n or len(c)!=n: return None
    A=[[0]*n for _ in range(n)]
    remr=list(r)
    cols=sorted(range(n), key=lambda j:-c[j])
    remc=list(c)
    for j in cols:
        d=remc[j]
        if d==0: continue
        if d>n: return None
        rows=sorted(range(n), key=lambda i:-remr[i])
        for i in rows[:d]:
            if remr[i]<=0: return None
            A[i][j]=1; remr[i]-=1
    if any(x!=0 for x in remr): return None
    return A

def achievable(n):
    parts={}
    for s in range(0,n+1):
        parts[s]=partitions(s,n,n)
    S=set()
    for total in range(0,n*n+1):
        rs=[]
        for s in range(0,total+1):
            if s>n*n: break
            rs += parts.get(s,[]) if s<=n*n else []
        # rows sums range 0..n per row; total <= n*n
        rowlists=[]
        for s in range(max(0,total-n*n), min(total,n*n)+1):
            rowlists += parts.get(s,[])
        for r in rowlists:
            for c in rowlists:
                pass
    return S

def achievable2(n):
    allparts=[]
    for s in range(0,n*n+1):
        # partitions of s into at most n parts each <= n
        allparts += [(s,p) for p in partitions(s,n,n)]
    bytotal={}
    for s,p in allparts:
        bytotal.setdefault(s,[]).append(p)
    S=set()
    for t,pl in bytotal.items():
        if t>n*n: continue
        for r in pl:
            for c in pl:
                A=build(r,c,n)
                if A is None: continue
                S.add(f_scc(A,n))
    return S

if __name__=="__main__":
    for n in range(2,11):
        S=achievable2(n)
        print("n=%2d |S|=%3d  min=%3d max=%3d"%(n,len(S),min(S),max(S)))
        print("     ", sorted(S))
        sys.stdout.flush()
