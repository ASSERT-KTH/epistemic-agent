import random
from collections import defaultdict

def fixed_count_via_cycles(A, n):
    """k = #cells not on any directed cycle of D.
    D: arc r->c if A[r][c]==1, arc c->r if A[r][c]==0.
    A cell is non-fixed iff its arc lies on a directed cycle, i.e. both
    endpoints are in the same non-trivial SCC."""
    V = 2 * n                      # 0..n-1 rows, n..2n-1 cols
    adj = [[] for _ in range(V)]
    for i in range(n):
        for j in range(n):
            if A[i][j] == 1:
                adj[i].append(n + j)
            else:
                adj[n + j].append(i)
    # iterative Tarjan SCC
    index = [-1] * V; low = [0] * V; onstk = [False] * V
    stk = []; comp = [-1] * V; counter = [0]; ncomp = [0]
    for s in range(V):
        if index[s] != -1:
            continue
        work = [(s, 0)]
        while work:
            v, pi = work[-1]
            if pi == 0:
                index[v] = low[v] = counter[0]; counter[0] += 1
                stk.append(v); onstk[v] = True
            recurse = False
            while pi < len(adj[v]):
                w = adj[v][pi]; pi += 1
                if index[w] == -1:
                    work[-1] = (v, pi)
                    work.append((w, 0)); recurse = True; break
                elif onstk[w]:
                    low[v] = min(low[v], index[w])
            if recurse:
                continue
            work[-1] = (v, pi)
            if pi >= len(adj[v]):
                work.pop()
                if low[v] == index[v]:
                    while True:
                        w = stk.pop(); onstk[w] = False
                        comp[w] = ncomp[0]
                        if w == v: break
                    ncomp[0] += 1
                if work:
                    u, _ = work[-1]
                    low[u] = min(low[u], low[v])
    size = [0] * ncomp[0]
    for v in range(V):
        size[comp[v]] += 1
    k = 0
    for i in range(n):
        for j in range(n):
            u, w = i, n + j
            if comp[u] != comp[w] or size[comp[u]] == 1:
                k += 1
    return k

def enumerate_class(n, r, c):
    """All binary matrices with row sums r, col sums c."""
    res = []
    m = [[0] * n for _ in range(n)]
    def go(i, colleft):
        if i == n:
            if all(x == 0 for x in colleft):
                res.append([row[:] for row in m])
            return
        for mask in range(1 << n):
            cnt = bin(mask).count('1')
            if cnt != r[i]:
                continue
            ok = True
            for j in range(n):
                if (mask >> j) & 1 and colleft[j] <= 0:
                    ok = False; break
            if not ok:
                continue
            for j in range(n):
                if (mask >> j) & 1:
                    colleft[j] -= 1
            m[i] = [(mask >> j) & 1 for j in range(n)]
            go(i + 1, colleft)
            for j in range(n):
                if (mask >> j) & 1:
                    colleft[j] += 1
    go(0, list(c))
    return res

def fixed_count_explicit(ms, n):
    k = 0
    for i in range(n):
        for j in range(n):
            if len(set(m[i][j] for m in ms)) == 1:
                k += 1
    return k

if __name__ == "__main__":
    random.seed(1)
    for n in (4, 5):
        for trial in range(60):
            dens = random.random()
            A = [[1 if random.random() < dens else 0 for _ in range(n)] for _ in range(n)]
            k1 = fixed_count_via_cycles(A, n)
            r = [sum(row) for row in A]; c = [sum(A[i][j] for i in range(n)) for j in range(n)]
            ms = enumerate_class(n, r, c)
            k2 = fixed_count_explicit(ms, n)
            assert k1 == k2, (n, A, k1, k2)
        print("n=%d: directed-cycle method matches full class enumeration on 60 random matrices" % n)
