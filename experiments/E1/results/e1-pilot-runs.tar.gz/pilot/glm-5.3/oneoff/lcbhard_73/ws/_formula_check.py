import random
from collections import Counter

def f_scc(A, n):
    """Exact class invariant: k = #cells whose arc is on no directed cycle."""
    V = 2 * n
    adj = [[] for _ in range(V)]
    for i in range(n):
        for j in range(n):
            if A[i][j] == 1:
                adj[i].append(n + j)
            else:
                adj[n + j].append(i)
    index = [-1]*V; low=[0]*V; onstk=[False]*V
    stk=[]; comp=[-1]*V; cnt=[0]; nc=[0]
    for s in range(V):
        if index[s] != -1: continue
        work=[(s,0)]
        while work:
            v,pi=work[-1]
            if pi==0:
                index[v]=low[v]=cnt[0]; cnt[0]+=1
                stk.append(v); onstk[v]=True
            rec=False
            while pi<len(adj[v]):
                w=adj[v][pi]; pi+=1
                if index[w]==-1:
                    work[-1]=(v,pi); work.append((w,0)); rec=True; break
                elif onstk[w]:
                    low[v]=min(low[v],index[w])
            if rec: continue
            work[-1]=(v,pi)
            if pi>=len(adj[v]):
                work.pop()
                if low[v]==index[v]:
                    while True:
                        w=stk.pop(); onstk[w]=False; comp[w]=nc[0]
                        if w==v: break
                    nc[0]+=1
                if work:
                    u,_=work[-1]; low[u]=min(low[u],low[v])
    size=[0]*nc[0]
    for v in range(V): size[comp[v]]+=1
    k=0
    for i in range(n):
        for j in range(n):
            u,w=i,n+j
            if comp[u]!=comp[w] or size[comp[u]]==1: k+=1
    return k

def f_formula(A, n):
    r=[sum(row) for row in A]
    c=[sum(A[i][j] for i in range(n)) for j in range(n)]
    a=sum(1 for x in r if x==1); b=sum(1 for x in c if x==1)
    p=sum(1 for x in r if x==n-1); q=sum(1 for x in c if x==n-1)
    return min(a,b)+min(p,q)

if __name__=="__main__":
    rng=random.Random(12345)
    for n in (3,4,5,6,7):
        bad=0; tested=0
        classes={}
        for _ in range(4000):
            d=rng.random()
            A=[[1 if rng.random()<d else 0 for _ in range(n)] for _ in range(n)]
            k1=f_scc(A,n); k2=f_formula(A,n)
            tested+=1
            if k1!=k2:
                bad+=1
                if bad<=3:
                    print("MISMATCH n=%d scc=%d formula=%d"%(n,k1,k2))
                    for row in A: print("   ",row)
        print("n=%d: %d matrices tested, %d mismatches"%(n,tested,bad))
