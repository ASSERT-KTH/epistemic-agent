import random

def f_scc(A, n):
    V = 2*n
    adj=[[] for _ in range(V)]
    for i in range(n):
        for j in range(n):
            if A[i][j]==1: adj[i].append(n+j)
            else: adj[n+j].append(i)
    index=[-1]*V; low=[0]*V; onstk=[False]*V
    stk=[]; comp=[-1]*V; cnt=[0]; nc=[0]
    for s in range(V):
        if index[s]!=-1: continue
        work=[(s,0)]
        while work:
            v,pi=work[-1]
            if pi==0:
                index[v]=low[v]=cnt[0]; cnt[0]+=1
                stk.append(v); onstk[v]=True
            rec=False
            while pi<len(adj[v]):
                w=adj[v][pi]; pi+=1
                if index[w]==-1:
                    work[-1]=(v,pi); work.append((w,0)); rec=True; break
                elif onstk[w]: low[v]=min(low[v],index[w])
            if rec: continue
            work[-1]=(v,pi)
            if pi>=len(adj[v]):
                work.pop()
                if low[v]==index[v]:
                    while True:
                        w=stk.pop(); onstk[w]=False; comp[w]=nc[0]
                        if w==v: break
                    nc[0]+=1
                if work:
                    u,_=work[-1]; low[u]=min(low[u],low[v])
    size=[0]*nc[0]
    for v in range(V): size[comp[v]]+=1
    k=0
    for i in range(n):
        for j in range(n):
            if comp[i]!=comp[n+j] or size[comp[i]]==1: k+=1
    return k, comp

def rand_switch(B, n, rng):
    """Apply a margin-preserving 2x2 interchange (true checkerboard switch)."""
    for _ in range(200):
        i1=rng.randrange(n); i2=rng.randrange(n); j1=rng.randrange(n); j2=rng.randrange(n)
        if i1==i2 or j1==j2: continue
        if B[i1][j1]==B[i2][j2] and B[i1][j1]!=B[i1][j2] and B[i1][j1]!=B[i2][j1]:
            B[i1][j1]^=1; B[i2][j2]^=1; B[i1][j2]^=1; B[i2][j1]^=1
            return True
    return False

if __name__=="__main__":
    rng=random.Random(2024)
    # 1) class invariance under correct interchanges
    for n in (4,5,6,7):
        bad=0
        for _ in range(400):
            d=rng.random()
            A=[[1 if rng.random()<d else 0 for _ in range(n)] for _ in range(n)]
            k0,_=f_scc(A,n)
            B=[row[:] for row in A]
            for _ in range(30):
                rand_switch(B,n,rng)
            k1,_=f_scc(B,n)
            # margins must match
            assert [sum(r) for r in A]==[sum(r) for r in B]
            assert [sum(A[i][j] for i in range(n)) for j in range(n)]==[sum(B[i][j] for i in range(n)) for j in range(n)]
            if k0!=k1: bad+=1
        print("n=%d: 400 classes, 30 interchanges each -> %d invariant violations"%(n,bad))

    # 2) cross-block uniformity: cells between two distinct SCCs are all equal
    for n in (4,5,6,7):
        bad=0
        for _ in range(400):
            d=rng.random()
            A=[[1 if rng.random()<d else 0 for _ in range(n)] for _ in range(n)]
            k,comp=f_scc(A,n)
            ok=True
            for i1 in range(n):
                for i2 in range(n):
                    for j1 in range(n):
                        for j2 in range(n):
                            if comp[i1]==comp[n+j1] or comp[i2]==comp[n+j2]: continue
                            if comp[i1]==comp[i2] and comp[n+j1]==comp[n+j2]:
                                if A[i1][j1]!=A[i2][j2]: ok=False
            if not ok: bad+=1
        print("n=%d: 400 matrices -> %d cross-block uniformity violations"%(n,bad))
