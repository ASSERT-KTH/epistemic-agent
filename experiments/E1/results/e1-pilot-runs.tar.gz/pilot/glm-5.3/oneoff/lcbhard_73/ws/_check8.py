from collections import defaultdict
from itertools import product

def matrices(n, r, c):
    """All binary matrices with row sums r and column sums c (backtracking)."""
    res = []
    m = [[0]*n for _ in range(n)]
    def go(i, colleft, cur):
        if i == n:
            if all(x == 0 for x in colleft):
                res.append([row[:] for row in m])
            return
        # choose positions of r[i] ones in row i
        for combo in product([0,1], repeat=n):
            if sum(combo) != r[i]:
                continue
            ok = True
            for j in range(n):
                if combo[j] and colleft[j] <= 0:
                    ok = False
                    break
            if not ok:
                continue
            for j in range(n):
                if combo[j]:
                    colleft[j] -= 1
            m[i] = list(combo)
            go(i+1, colleft, cur)
            m[i] = [0]*n
            for j in range(n):
                if combo[j]:
                    colleft[j] += 1
    go(0, list(c), None)
    return res

def fixed_count(ms, n):
    fixed = 0
    for i in range(n):
        for j in range(n):
            vals = set(m[i][j] for m in ms)
            if len(vals) == 1:
                fixed += 1
    return fixed

def brute_classes(n):
    n2 = n*n
    classes = defaultdict(lambda: [(1 << n2) - 1, 0])
    for bits in range(1 << n2):
        r = []
        c = [0]*n
        for i in range(n):
            ri = 0
            for j in range(n):
                b = (bits >> (i*n+j)) & 1
                ri += b
                c[j] += b
            r.append(ri)
        e = classes[(tuple(r), tuple(c))]
        e[0] &= bits
        e[1] |= bits
    return classes

if __name__ == "__main__":
    import sys
    n = 4
    classes = brute_classes(n)
    # find classes with k=8 and re-verify with explicit enumeration
    for (r, c), (a, o) in sorted(classes.items()):
        same = (a & o) | ((~a & ~o) & ((1 << (n*n)) - 1))
        k = bin(same).count('1')
        if k == 8:
            ms = matrices(n, list(r), list(c))
            k2 = fixed_count(ms, n)
            print("class r=%s c=%s  bitmask-k=%d  explicit-k=%d  #matrices=%d"
                  % (r, c, k, k2, len(ms)))
            for m in ms[:6]:
                print("   ", m)
            print()
