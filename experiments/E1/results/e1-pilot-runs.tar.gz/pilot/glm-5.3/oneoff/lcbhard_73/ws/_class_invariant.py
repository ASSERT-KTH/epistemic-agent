import random

def f_scc(A, n):
    V = 2*n
    adj=[[] for _ in range(V)]
    for i in range(n):
        for j in range(n):
            if A[i][j]==1: adj[i].append(n+j)
            else: adj[n+j].append(i)
    index=[-1]*V; low=[0]*V; onstk=[False]*V
    stk=[]; comp=[-1]*V; cnt=[0]; nc=[0]
    for s in range(V):
        if index[s]!=-1: continue
        work=[(s,0)]
        while work:
            v,pi=work[-1]
            if pi==0:
                index[v]=low[v]=cnt[0]; cnt[0]+=1
                stk.append(v); onstk[v]=True
            rec=False
            while pi<len(adj[v]):
                w=adj[v][pi]; pi+=1
                if index[w]==-1:
                    work[-1]=(v,pi); work.append((w,0)); rec=True; break
                elif onstk[w]: low[v]=min(low[v],index[w])
            if rec: continue
            work[-1]=(v,pi)
            if pi>=len(adj[v]):
                work.pop()
                if low[v]==index[v]:
                    while True:
                        w=stk.pop(); onstk[w]=False; comp[w]=nc[0]
                        if w==v: break
                    nc[0]+=1
                if work:
                    u,_=work[-1]; low[u]=min(low[u],low[v])
    size=[0]*nc[0]
    for v in range(V): size[comp[v]]+=1
    k=0
    for i in range(n):
        for j in range(n):
            if comp[i]!=comp[n+j] or size[comp[i]]==1: k+=1
    return k

def random_in_class(A, n, steps, rng):
    B=[row[:] for row in A]
    for _ in range(steps):
        i1=rng.randrange(n); i2=rng.randrange(n); j1=rng.randrange(n); j2=rng.randrange(n)
        if i1!=i2 and j1!=j2 and B[i1][j1]==B[i2][j2] and B[i1][j2]!=B[i1][j1]:
            B[i1][j1]=1-B[i1][j1]; B[i2][j2]=1-B[i2][j2]
            B[i1][j2]=1-B[i1][j2]; B[i2][j1]=1-B[i2][j1]
    return B

if __name__=="__main__":
    rng=random.Random(999)
    for n in (4,5,6):
        mismatch=0
        for _ in range(300):
            d=rng.random()
            A=[[1 if rng.random()<d else 0 for _ in range(n)] for _ in range(n)]
            k=f_scc(A,n)
            for _ in range(5):
                B=random_in_class(A,n,40,rng)
                if f_scc(B,n)!=k:
                    mismatch+=1
                    print("CLASS INVARIANT VIOLATED n=%d"%n)
                    for row in A: print("  A",row)
                    for row in B: print("  B",row)
                    break
        print("n=%d: 300 random classes x 5 perturbations, %d violations"%(n,mismatch))
