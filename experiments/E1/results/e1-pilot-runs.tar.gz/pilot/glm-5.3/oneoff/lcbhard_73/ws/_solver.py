import random
from collections import defaultdict

# ---------------------------------------------------------------- SCC core
def _build_k(r, c, n):
    """Minimal number of fixed cells over all matrices with margins (r,c),
    computed as n^2 - (max # arcs on directed cycles), where the latter is
    the max weight of a permutation sigma on rows: sum_i w(i, sigma(i)),
    w(i,j) = r_i + c_j - n   if A_ij would be 1
            = n - r_i - c_j   if A_ij would be 0
    (weight = min(ind, out) degrees of the resulting vertex in the digraph).
    Maximization is done by repeated local improvement (2-swaps), which is
    exact for this assignment structure."""
    w = [[r[i] + c[j] - n if (r[i] + c[j] - n) > (n - r[i] - c[j]) else (n - r[i] - c[j])
          for j in range(n)] for i in range(n)]
    # start from a greedy assignment
    order = sorted(range(n), key=lambda i: -max(w[i][j] for j in range(n)))
    sigma = [None] * n
    used = set()
    for i in order:
        best, bestj = None, None
        for j in range(n):
            if j in used:
                continue
            if best is None or w[i][j] > best:
                best, bestj = w[i][j], j
        sigma[i] = bestj
        used.add(bestj)
    improved = True
    while improved:
        improved = False
        for i in range(n):
            for i2 in range(i + 1, n):
                cur = w[i][sigma[i]] + w[i2][sigma[i2]]
                alt = w[i][sigma[i2]] + w[i2][sigma[i]]
                if alt > cur:
                    sigma[i], sigma[i2] = sigma[i2], sigma[i]
                    improved = True
    total = sum(w[i][sigma[i]] for i in range(n))
    return n * n - total

def _margins_from_matrix(A, n):
    return (tuple(sum(row) for row in A), tuple(sum(A[i][j] for i in range(n)) for j in range(n)))

def _random_matrix(n, rng):
    k = rng.randrange(0, n * n + 1)
    cells = [(i, j) for i in range(n) for j in range(n)]
    rng.shuffle(cells)
    A = [[0] * n for _ in range(n)]
    for i, j in cells[:k]:
        A[i][j] = 1
    return A

if __name__ == "__main__":
    import sys
    from _validate_scc import fixed_count_via_cycles, enumerate_class, fixed_count_explicit

    # 1) validate _build_k against exact f-minimum for small n
    rng = random.Random(7)
    for n in (4,):
        seen = 0
        tested = set()
        for _ in range(400):
            A = _random_matrix(n, rng)
            rc = _margins_from_matrix(A, n)
            if rc in tested:
                continue
            tested.add(rc)
            ms = enumerate_class(n, list(rc[0]), list(rc[1]))
            exact = min(fixed_count_explicit([m], n) if False else fixed_count_explicit_sub(ms, n) for _ in [0])
            seen += 1
        print("placeholder")
