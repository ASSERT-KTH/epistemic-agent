from collections import defaultdict

MOD = 998244353

def brute(N, M, K, edges):
    """Straightforward O(K * edges) DP: distribution over vertices, K steps."""
    adj = defaultdict(list)
    for i in range(1, N + 1):
        adj[i].append(i % N + 1)
    for x, y in edges:
        adj[x].append(y)
    cur = {1: 1}
    for _ in range(K):
        nxt = defaultdict(int)
        for v, c in cur.items():
            for w in adj[v]:
                nxt[w] = (nxt[w] + c) % MOD
        cur = nxt
    return sum(cur.values()) % MOD

if __name__ == "__main__":
    print("t1:", brute(6, 2, 5, [(1, 4), (2, 5)]), "expected 5")
    print("t2:", brute(10, 0, 200000, []), "docstring says 1, test says 0")
    print("t3:", brute(199, 10, 1326, [(122, 39), (142, 49), (164, 119), (197, 127), (188, 145),
                                       (69, 80), (6, 120), (24, 160), (18, 154), (185, 27)]), "expected 451022766")
    print("t4:", brute(119, 8, 142, [(64, 24), (118, 116), (97, 50), (64, 26),
                                     (45, 75), (9, 66), (29, 41), (107, 78)]), "expected 2143")
    print("t5:", brute(624, 23, 746, [(259, 346), (471, 98), (21, 216), (618, 111), (296, 500),
                                      (505, 490), (256, 578), (273, 623), (578, 281), (386, 322),
                                      (426, 230), (417, 134), (533, 199), (216, 535), (71, 81),
                                      (338, 18), (71, 331), (623, 120), (270, 145), (358, 447),
                                      (508, 33), (286, 96), (451, 145)]), "expected 380317052")
    print("t6:", brute(40, 24, 21, [(1, 6), (26, 4), (31, 28), (3, 38), (13, 20), (21, 35),
                                    (26, 39), (25, 7), (17, 26), (5, 33), (18, 13), (11, 19),
                                    (2, 5), (16, 20), (30, 19), (6, 22), (20, 27), (18, 16),
                                    (27, 6), (6, 20), (39, 8), (40, 34), (30, 18), (2, 4)]), "expected 17354")
