"""Trace the 'own' (take into hand) rules on (1,1,1,[11],[5],[10]) to see why the solver says Aoki."""
from functools import lru_cache
import sys
sys.setrecursionlimit(100000)

T = (11,); A = (5,); S = (10,)

@lru_cache(maxsize=None)
def fw(t, a, s, turn, depth=0):
    hand = t if turn == 0 else a
    if not hand:
        print("  " * depth, f"terminal turn={turn} (mover has no card) -> mover loses")
        return False
    res = []
    for i, c in enumerate(hand):
        rest = hand[:i] + hand[i+1:]
        nt, na = (rest, a) if turn == 0 else (t, rest)
        ns0 = tuple(sorted(s + (c,)))
        r = fw(nt, na, ns0, 1 - turn, depth + 1)
        print("  " * depth, f"turn={turn} play {c} no-take -> table {ns0} => {r}")
        res.append(r)
        for d in s:
            if d < c:
                lst = list(s); lst.remove(d)
                ns = tuple(sorted(lst + [c]))
                nh = tuple(sorted(rest + (d,)))
                nnt, nna = (nh, na) if turn == 0 else (nt, nh)
                r = fw(nnt, nna, ns, 1 - turn, depth + 1)
                print("  " * depth, f"turn={turn} play {c} take {d} -> hand {nh} table {ns} => {r}")
                res.append(r)
    return any(res)

print("first player wins?", fw(T, A, S, 0))
