"""Rule-interpretation search, take 2 (corrected terminal condition).

`solve` returns True iff the player who moves FIRST (Takahashi) wins.
A player who has no card in hand (or no legal move) loses immediately.
"""
import sys
from functools import lru_cache
from itertools import product
from search import TESTS


def make_solver(cmp_mode, take_mode, dest, to_table):
    def ok(d, c):
        return d < c if cmp_mode == 'lt' else d <= c

    def solve(T, A, S, max_nodes=2000):
        T = tuple(sorted(T)); A = tuple(sorted(A)); S = tuple(sorted(S))
        counter = [0]

        @lru_cache(maxsize=None)
        def fw(t, a, s, turn):
            counter[0] += 1
            if counter[0] > max_nodes:
                raise RuntimeError("too big")
            hand = t if turn == 0 else a
            if not hand:
                return turn == 1          # mover cannot move -> mover loses
            res = []
            for i, c in enumerate(hand):
                rest = hand[:i] + hand[i + 1:]
                nt, na = (rest, a) if turn == 0 else (t, rest)
                ns0 = tuple(sorted(s + (c,))) if to_table else s
                takes = [d for d in s if ok(d, c)]
                if take_mode != 'required':
                    res.append(fw(nt, na, ns0, 1 - turn))
                for d in takes:
                    if to_table:
                        lst = list(s); lst.remove(d)
                        ns = tuple(sorted(lst + [c]))
                    else:
                        ns = tuple(x for x in s if x != d)
                    if dest == 'gone':
                        res.append(fw(nt, na, ns, 1 - turn))
                    elif dest == 'own':
                        nh = tuple(sorted(rest + (d,)))
                        nnt, nna = (nh, na) if turn == 0 else (nt, nh)
                        res.append(fw(nnt, nna, ns, 1 - turn))
                    else:  # opponent's hand
                        oh = a if turn == 0 else t
                        noh = tuple(sorted(oh + (d,)))
                        nnt, nna = (noh, na) if turn == 0 else (nt, noh)
                        res.append(fw(nnt, nna, ns, 1 - turn))
            if not res:
                return turn == 1          # mover has no legal move -> mover loses
            return any(res)

        try:
            return fw(T, A, S, 0)
        except RuntimeError:
            return None
    return solve


def main():
    small = [t for t in TESTS if len(t[3]) + len(t[4]) + len(t[5]) <= 5]
    print(f"{len(small)} small tests of {len(TESTS)}")
    best = None
    for cmp_mode, take_mode, dest, to_table in product(
            ['lt', 'le'], ['optional', 'forced', 'required'],
            ['gone', 'own'], [True, False]):
        solve = make_solver(cmp_mode, take_mode, dest, to_table)
        good, bad, unknown = 0, [], 0
        for (n, m, l, T, A, S, exp) in small:
            r = solve(T, A, S)
            if r is None:
                unknown += 1
                continue
            got = 'Takahashi' if r else 'Aoki'
            if got == exp:
                good += 1
            else:
                bad.append((n, m, l, T, A, S, exp, got))
        tag = (cmp_mode, take_mode, dest, to_table)
        print(f"{tag}: match {good}/{len(small)-unknown} (unknown {unknown})")
        if not bad and unknown == 0:
            print("  *** FULL SURVIVOR ***")
        if best is None or good > best[0]:
            best = (good, tag, bad)
    print("best:", best[1], best[0], "mismatches:", len(best[2]))
    for b in best[2][:15]:
        print("   ", b)


if __name__ == '__main__':
    sys.setrecursionlimit(100000)
    main()
