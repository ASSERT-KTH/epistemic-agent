import sys
from functools import lru_cache
sys.setrecursionlimit(100000)
from search import TESTS

def solve(T, A, S, cmp_mode='lt', dest='own', to_table=True):
    T = tuple(sorted(T)); A = tuple(sorted(A)); S = tuple(sorted(S))
    def ok(d, c): return d < c if cmp_mode == 'lt' else d <= c
    @lru_cache(maxsize=None)
    def fw(t, a, s, turn):
        hand = t if turn == 0 else a
        if not hand: return False
        res = []
        for i, c in enumerate(hand):
            rest = hand[:i] + hand[i+1:]
            nt, na = (rest, a) if turn == 0 else (t, rest)
            ns0 = tuple(sorted(s + (c,))) if to_table else s
            res.append(fw(nt, na, ns0, 1 - turn))
            for d in s:
                if ok(d, c):
                    if to_table:
                        lst = list(s); lst.remove(d); ns = tuple(sorted(lst + [c]))
                    else:
                        ns = tuple(x for x in s if x != d)
                    nh = tuple(sorted(rest + (d,)))
                    nnt, nna = (nh, na) if turn == 0 else (nt, nh)
                    res.append(fw(nnt, nna, ns, 1 - turn))
        return any(res)
    return fw(T, A, S, 0)

if __name__ == '__main__':
    for name, kw in [("own,lt,play", dict()), ("own,lt,noplay", dict(to_table=False))]:
        bad = 0; tot = 0
        for (n, m, l, T, A, S, exp) in TESTS:
            if len(T) + len(A) + len(S) > 9: continue
            tot += 1
            got = 'Takahashi' if solve(T, A, S, **kw) else 'Aoki'
            if got != exp:
                bad += 1
                print(f"[{name}] MISMATCH n={n},m={m},l={l} T={T} A={A} S={S} exp={exp} got={got}")
        print(f"[{name}] {tot-bad}/{tot} match")
