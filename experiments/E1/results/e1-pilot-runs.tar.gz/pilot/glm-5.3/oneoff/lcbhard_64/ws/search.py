"""Systematically search a family of rule interpretations for the card game,
checking each against every expectation in test.py."""
import sys
from functools import lru_cache
from itertools import product

TESTS = [
    (1, 1, 2, [2], [4], [1, 3], 'Aoki'),
    (4, 4, 4, [98, 98765, 987654, 987654321], [987, 9876, 9876543, 98765432], [123, 12345, 1234567, 123456789], 'Takahashi'),
    (1, 1, 8, [10], [10], [1, 2, 3, 4, 5, 6, 7, 8], 'Aoki'),
    (1, 2, 2, [870040648], [378785874, 441458426], [37774012, 656883965], 'Aoki'),
    (1, 1, 1, [11], [5], [10], 'Takahashi'),
    (2, 1, 1, [663968656, 858351977], [268979134], [976832603], 'Takahashi'),
    (4, 4, 4, [1000000000, 1000000000, 500000000, 500000000], [1000000000, 1000000000, 500000000, 500000000], [1000000000, 500000000, 1000000000, 500000000], 'Aoki'),
    (1, 2, 1, [15345183], [770220931, 810410746], [2531415], 'Aoki'),
    (1, 1, 10, [26], [77], [975789005, 935549121, 810914368, 801602978, 722142261, 477369028, 379913519, 304294676, 271235871, 109555729], 'Aoki'),
    (2, 1, 1, [846804653, 726066137], [169875224], [907767749], 'Takahashi'),
    (1, 1, 1, [840867097], [157151231], [918395672], 'Aoki'),
    (1, 1, 3, [133620429], [681825965], [202422474, 651050913, 891298200], 'Aoki'),
    (2, 2, 7, [572549073, 623682280], [330457472, 167936508], [404359286, 963871530, 157761505, 134471125, 863707511, 239248390, 339185829], 'Takahashi'),
    (7, 3, 2, [824247972, 452801554, 463552059, 187622641, 266242515, 486885044, 365488727], [561941336, 153080678, 381572895], [496536180, 678086129], 'Takahashi'),
    (1, 1, 1, [10], [10], [10], 'Takahashi'),
    (3, 1, 1, [783650879, 79180333, 965120264], [913189318], [734422155], 'Takahashi'),
    (1, 3, 2, [742787913], [31543862, 370918857, 373530871], [191026897, 10699019], 'Aoki'),
    (2, 1, 2, [877376242, 616183963], [680973952], [977122253, 573590700], 'Takahashi'),
    (1, 1, 2, [728610446], [852706870], [864480267, 556196498], 'Aoki'),
    (1, 2, 2, [127672085], [653221188, 697143448], [213155335, 938078652], 'Aoki'),
    (1, 2, 1, [688252252], [136709685, 256572433], [308258759], 'Takahashi'),
    (5, 5, 2, [1000000000] * 5, [1000000000] * 5, [1000000000, 1000000000], 'Aoki'),
    (1, 1, 5, [445776209], [830881544], [167672267, 788426433, 32964781, 849697914, 479660446], 'Aoki'),
    (2, 3, 4, [451220355, 321463980], [591392493, 447481177, 795512575], [994710564, 152775720, 634663584, 453321714], 'Aoki'),
    (2, 4, 5, [477612343, 679441277], [396485655, 684021329, 568232013, 62123607], [404190518, 438759066, 9049079, 447992443, 781877860], 'Aoki'),
    (1, 2, 2, [984641620], [609360020, 238052748], [256211902, 862585180], 'Aoki'),
    (4, 3, 5, [1, 2, 2, 3], [1, 1, 3], [2, 2, 2, 3, 3], 'Takahashi'),
    (1, 3, 1, [895333638], [124603598, 39075653, 650155154], [23232030], 'Aoki'),
    (8, 2, 1, [199134228, 855253648, 116624759, 297394540, 120429530, 599342913, 650199917, 738949452], [165226137, 854330363], [754408953], 'Takahashi'),
    (1, 1, 1, [289504574], [175943922], [160434248], 'Takahashi'),
    (2, 1, 5, [968437304, 42928924], [522015805], [274218981, 967518051, 28621664, 558413588, 715660902], 'Takahashi'),
    (2, 1, 5, [314888702, 396350480], [740308993], [26467748, 649450852, 250034854, 922532789, 152350479], 'Takahashi'),
    (1, 1, 2, [772777020], [902041077], [428233517, 762628806], 'Aoki'),
    (1, 1, 1, [431447526], [728549939], [448271189], 'Aoki'),
    (4, 3, 3, [312522779, 399927948, 450741117, 712100767], [49666652, 924464448, 141984972], [645542411, 22064990, 422840791], 'Takahashi'),
    (2, 2, 1, [403274796, 630421214], [312496981, 9553176], [148667020], 'Takahashi'),
    (3, 1, 2, [640582596, 959318626, 153857695], [223314722], [3470444, 219892448], 'Takahashi'),
    (1, 1, 1, [212644133], [805166324], [237359998], 'Aoki'),
    (1, 4, 1, [477363718], [398982752, 812410482, 204523721, 489057444], [382846737], 'Aoki'),
    (1, 1, 1, [961040770], [729580034], [633294197], 'Takahashi'),
    (3, 7, 1, [758377451, 806758605, 506199396], [99378076, 728188881, 534379399, 816140245, 249497575, 583837259, 818185918], [435193046], 'Aoki'),
    (1, 1, 1, [7], [14], [21], 'Aoki'),
    (1, 1, 2, [554617504], [932969235], [983025966, 42322430], 'Aoki'),
]


def solve(T, A, S, cmp_mode, take_mode, dest, to_table, first, loss_mode):
    """Return True if the player who moves first under `first` wins."""
    T = tuple(sorted(T)); A = tuple(sorted(A)); S = tuple(sorted(S))

    def ok(d, c):
        return d < c if cmp_mode == 'lt' else d <= c

    @lru_cache(maxsize=None)
    def first_player_wins(t, a, s, turn):
        # turn 0 = the original first player, 1 = the other
        hand = t if turn == 0 else a
        if not hand:
            return False  # mover has no card -> cannot move -> mover loses
        results = []
        for i, c in enumerate(hand):
            rest = hand[:i] + hand[i + 1:]
            nt, na = (rest, a) if turn == 0 else (t, rest)
            new_s_base = tuple(sorted(s + (c,))) if to_table else s
            # option: no take
            if take_mode in ('optional', 'forced'):
                results.append(first_player_wins(nt, na, new_s_base, 1 - turn))
            takes = [d for d in s if ok(d, c)]
            for d in takes:
                tmp = tuple(sorted(x for x in s if x != d)) if not to_table else None
                if to_table:
                    # table loses d, gains c
                    lst = [x for x in s]
                    lst.remove(d)
                    ns = tuple(sorted(lst + [c]))
                else:
                    ns = tmp
                if dest == 'gone':
                    results.append(first_player_wins(nt, na, ns, 1 - turn))
                elif dest == 'own':
                    nh = tuple(sorted(rest + (d,)))
                    nnt, nna = (nh, na) if turn == 0 else (nt, nh)
                    results.append(first_player_wins(nnt, nna, ns, 1 - turn))
                else:  # opponent gets it
                    oh = a if turn == 0 else t
                    noh = tuple(sorted(oh + (d,)))
                    nnt, nna = (noh, na) if turn == 0 else (nt, noh)
                    results.append(first_player_wins(nnt, nna, ns, 1 - turn))
            if take_mode == 'required' and not takes:
                pass  # playing c without being able to take is illegal
        if not results:
            return False  # no legal move -> mover loses
        return any(results)  # mover wants a win for himself

    return first_player_wins(T, A, S, 0)


def main():
    small = [t for t in TESTS if len(t[3]) + len(t[4]) + len(t[5]) <= 9]
    print(f"{len(small)} small tests of {len(TESTS)}")
    survivors = []
    for cmp_mode, take_mode, dest, to_table, first in product(
            ['lt', 'le'], ['optional', 'forced', 'required'],
            ['gone', 'own'], [True, False], [0, 1]):
        good = True
        for (n, m, l, T, A, S, exp) in small:
            if len(T) + len(A) + len(S) > 9:
                continue
            got_first = solve(T, A, S, cmp_mode, take_mode, dest, to_table, first, 'noCardLoses')
            # map: first==0 means Takahashi moves first
            t_wins = got_first if first == 0 else not got_first
            got = 'Takahashi' if t_wins else 'Aoki'
            if got != exp:
                good = False
                break
        if good:
            survivors.append((cmp_mode, take_mode, dest, to_table, first))
            print("SURVIVOR:", survivors[-1])
    print("total survivors on small:", len(survivors))


if __name__ == '__main__':
    sys.setrecursionlimit(100000)
    main()
