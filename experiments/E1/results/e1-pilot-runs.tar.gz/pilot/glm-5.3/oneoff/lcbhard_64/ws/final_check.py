"""Full-test evaluation of the reading that satisfies BOTH docstring examples:
on your turn you must play one card from your hand to the table, then MAY take
one table card with a strictly smaller value INTO YOUR HAND. A player with no
card to play loses. Returns True iff Takahashi (first player) wins."""
import sys
from functools import lru_cache
sys.setrecursionlimit(1000000)
from search import TESTS


def first_wins(T, A, S):
    T = tuple(sorted(T)); A = tuple(sorted(A)); S = tuple(sorted(S))

    @lru_cache(maxsize=None)
    def fw(t, a, s, turn):
        hand = t if turn == 0 else a
        if not hand:
            return turn == 1                # mover cannot play -> mover loses
        res = []
        for i, c in enumerate(hand):
            rest = hand[:i] + hand[i + 1:]
            nt, na = (rest, a) if turn == 0 else (t, rest)
            # option 1: play c, take nothing
            res.append(fw(nt, na, tuple(sorted(s + (c,))), 1 - turn))
            # option 2: play c, take one strictly smaller table card into hand
            for j, d in enumerate(s):
                if d < c:
                    ns = s[:j] + s[j + 1:] + (c,)
                    nh = tuple(sorted(rest + (d,)))
                    nnt, nna = (nh, na) if turn == 0 else (nt, nh)
                    res.append(fw(nnt, nna, tuple(sorted(ns)), 1 - turn))
        return any(res)

    return fw(T, A, S, 0)


if __name__ == '__main__':
    ok = bad = 0
    for (n, m, l, T, A, S, exp) in TESTS:
        got = 'Takahashi' if first_wins(T, A, S) else 'Aoki'
        if got == exp:
            ok += 1
        else:
            bad += 1
            print(f"MISMATCH n={n} m={m} l={l} T={T} A={A} S={S} expected={exp} computed={got}")
    print(f"\n{ok}/{ok+bad} tests agree with the docstring reading; {bad} disagree")
