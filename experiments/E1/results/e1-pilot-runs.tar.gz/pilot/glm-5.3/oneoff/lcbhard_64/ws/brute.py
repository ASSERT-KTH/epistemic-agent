"""Brute-force reference solver for the card game, used to pin down the rules."""
from functools import lru_cache
import sys

def winner(T, A, S):
    T = tuple(sorted(T))
    A = tuple(sorted(A))
    S = tuple(sorted(S))

    @lru_cache(maxsize=None)
    def t_wins(t, a, s, turn):
        """True iff Takahashi eventually wins from this state.
        turn == 0 -> Takahashi to move, turn == 1 -> Aoki to move.
        A player with no card in hand cannot move and loses."""
        hand = t if turn == 0 else a
        if not hand:
            return turn == 1          # mover (Takahashi) loses -> Aoki wins... wait
        outcomes = []
        for i, c in enumerate(hand):
            rest = hand[:i] + hand[i+1:]
            nt, na = (rest, a) if turn == 0 else (t, rest)
            # option 1: play c, take nothing
            cands = [tuple(sorted(s + (c,)))]
            # option 2: play c, take some d < c from the table
            for j, d in enumerate(s):
                if d < c:
                    tmp = list(s)
                    tmp[j] = c
                    cands.append(tuple(sorted(tmp)))
            for ns in cands:
                if turn == 0:
                    outcomes.append(t_wins(nt, na, ns, 1))
                else:
                    outcomes.append(t_wins(nt, na, ns, 0))
        # mover picks the outcome best for himself:
        # Takahashi needs one winning move; Aoki needs one T-losing move,
        # so Takahashi only wins if ALL of Aoki's options are T-winning.
        if turn == 0:
            return any(outcomes)
        return all(outcomes)

    return 'Takahashi' if t_wins(T, A, S, 0) else 'Aoki'

if __name__ == '__main__':
    sys.setrecursionlimit(100000)
    print(winner([2], [4], [1, 3]))    # docstring: Aoki
    print(winner([11], [5], [10]))     # docstring: Takahashi
