from functools import lru_cache

T=tuple([2]); A=tuple([4]); S=tuple(sorted([1,3]))

@lru_cache(maxsize=None)
def t_wins(t,a,s,turn,depth=0):
    hand = t if turn==0 else a
    if not hand:
        print("  "*depth, "TERMINAL turn=",turn,"-> T wins?", turn==1)
        return turn==1
    outcomes=[]
    for i,c in enumerate(hand):
        rest = hand[:i]+hand[i+1:]
        nt,na = (rest,a) if turn==0 else (t,rest)
        cands=[("notake",tuple(sorted(s+(c,))))]
        for j,d in enumerate(s):
            if d<c:
                tmp=list(s); tmp[j]=c
                cands.append(("take%d"%d,tuple(sorted(tmp))))
        for lab,ns in cands:
            r = t_wins(nt,na,ns,1-turn,depth+1)
            print("  "*depth, "turn",turn,"play",c,lab,"-> table",ns,"T-wins?",r)
            outcomes.append(r)
    if turn==0: return any(outcomes)
    return not all(outcomes)

print("RESULT:", t_wins(T,A,S,0))
