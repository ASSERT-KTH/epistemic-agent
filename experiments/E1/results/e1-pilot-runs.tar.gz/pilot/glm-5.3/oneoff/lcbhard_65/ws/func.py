def max_eleven_twentytwo_subsequence(s: str, l: int, r: int) -> int:
    """ Find the maximum length of a subsequence within s[l-1:r] that forms an 11/22 string.

    An 11/22 string is defined as:
    - It has odd length
    - The first (len+1)//2 - 1 characters are all '1'
    - The middle character at position (len+1)//2 is '/'
    - The remaining characters are all '2'

    For example: '/', '1/2', '11/22', '111/222' are 11/22 strings.

    Args:
        s: A string consisting of characters '1', '2', and '/'
        l: Starting position (1-indexed)
        r: Ending position (1-indexed, inclusive)

    Returns:
        The maximum length of a subsequence that forms an 11/22 string, or 0 if none exists.

    >>> max_eleven_twentytwo_subsequence('111/212', 1, 7)
    5
    >>> max_eleven_twentytwo_subsequence('111/212/1122', 9, 12)
    0
    >>> max_eleven_twentytwo_subsequence('111/212/1122', 3, 6)
    3
    """
    n = len(s)
    # Clamp the window to the string bounds (defensive; tests stay in range).
    lo = max(0, l - 1)
    hi = min(n, r)
    if hi <= lo:
        return 0

    # Prefix counts: ones[i] = number of '1' in s[:i], twos[i] = number of '2' in s[:i].
    ones = [0] * (n + 1)
    twos = [0] * (n + 1)
    for i, ch in enumerate(s):
        ones[i + 1] = ones[i] + (1 if ch == '1' else 0)
        twos[i + 1] = twos[i] + (1 if ch == '2' else 0)

    best = 0
    # An 11/22 subsequence of length 2k+1 is: k '1's, one '/', then k '2's,
    # in that order.  It contains exactly one '/', so fix which '/' is used.
    for j in range(lo, hi):
        if s[j] != '/':
            continue
        ones_before = ones[j] - ones[lo]      # '1's available before the '/'
        twos_after = twos[hi] - twos[j + 1]   # '2's available after the '/'
        k = min(ones_before, twos_after)
        length = 2 * k + 1
        if length > best:
            best = length
    return best
