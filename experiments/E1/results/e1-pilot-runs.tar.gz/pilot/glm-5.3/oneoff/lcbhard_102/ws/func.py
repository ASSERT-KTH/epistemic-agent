from functools import lru_cache
from typing import List


def kth_alternating_permutation(n: int, k: int) -> List[int]:
    """ Given two integers n and k, return the k-th alternating permutation of the first n positive integers.

    An alternating permutation is a permutation where no two adjacent elements are both odd or both even.
    The permutations are sorted in lexicographical order.

    If there are fewer than k valid alternating permutations, return an empty list.

    Args:
        n: The number of elements in the permutation (1 <= n <= 100)
        k: The 1-indexed position of the desired permutation (1 <= k <= 10^15)

    Returns:
        The k-th alternating permutation, or an empty list if k is out of range

    >>> kth_alternating_permutation(4, 6)
    [3, 4, 1, 2]
    >>> kth_alternating_permutation(3, 2)
    [3, 2, 1]
    >>> kth_alternating_permutation(2, 3)
    []
    """
    n_odd = (n + 1) // 2   # count of odd values in 1..n
    n_even = n // 2        # count of even values in 1..n

    # Alternation is possible only if the parity counts differ by at most one.
    if abs(n_odd - n_even) > 1:
        return []

    @lru_cache(maxsize=None)
    def ways(last_parity, rem_e, rem_o):
        """Number of alternating completions when `rem_e` even and `rem_o` odd
        values remain and the previously placed value had parity `last_parity`
        (None when nothing has been placed yet).

        Only the parity of the last placed value matters: the concrete values
        still available are interchangeable for counting, which is why each
        parity choice is weighted by the number of remaining values of that
        parity."""
        if rem_e == 0 and rem_o == 0:
            return 1
        total = 0
        if rem_e > 0 and last_parity != 0:
            total += rem_e * ways(0, rem_e - 1, rem_o)
        if rem_o > 0 and last_parity != 1:
            total += rem_o * ways(1, rem_e, rem_o - 1)
        return total

    if k > ways(None, n_even, n_odd):
        return []

    result: List[int] = []
    used = [False] * (n + 1)
    last_parity = None
    rem_e, rem_o = n_even, n_odd
    remaining = k

    while len(result) < n:
        for value in range(1, n + 1):
            if used[value]:
                continue
            parity = value & 1
            if parity == last_parity:
                continue
            new_e = rem_e - (parity == 0)
            new_o = rem_o - (parity == 1)
            cnt = ways(parity, new_e, new_o)
            if remaining > cnt:
                remaining -= cnt
                continue
            used[value] = True
            result.append(value)
            last_parity = parity
            rem_e, rem_o = new_e, new_o
            break
        else:  # pragma: no cover - unreachable for a validated k
            return []

    return result
