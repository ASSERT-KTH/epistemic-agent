from typing import List

MOD = 10 ** 9 + 7


def sum_of_subsequence_powers(nums: List[int], k: int) -> int:
    """ Given an integer array nums and a positive integer k, calculate the sum of powers
    of all subsequences of nums. The power of a subsequence is defined as the number of
    its subsequences that sum to k.
    
    Return the sum modulo 10^9 + 7.
    
    Args:
        nums: List of integers where 1 <= len(nums) <= 100 and 1 <= nums[i] <= 10^4
        k: Target sum where 1 <= k <= 100
    
    Returns:
        The sum of powers of all subsequences modulo 10^9 + 7
    
    >>> sum_of_subsequence_powers([1, 2, 3], 3)
    6
    >>> sum_of_subsequence_powers([2, 3, 3], 5)
    4
    >>> sum_of_subsequence_powers([1, 2, 3], 7)
    0
    """
    # The answer counts ordered pairs (S, T) where T is a subsequence of S and
    # sum(T) == k.  Rearranged, for a fixed T (a subsequence of nums with sum k),
    # every superset S of T is counted, and there are exactly 2 ** (n - |T|)
    # supersets since each of the n - |T| remaining elements may be included or
    # not.  Hence:
    #
    #     answer = sum over subsequences T with sum(T) == k of 2 ** (n - |T|)
    #
    # This is computed with a knapsack-style DP over the reachable sums 0..k,
    # where dp[j] holds sum_{T: sum(T) == j} 2 ** (n_so_far - |T|) (mod MOD):
    # every element not placed into T doubles the weight of every existing T.
    dp = [0] * (k + 1)
    dp[0] = 1  # the empty subsequence T, weight 2 ** 0
    for x in nums:
        ndp = [(2 * dp[j]) % MOD for j in range(k + 1)]  # x left out of T
        for j in range(x, k + 1):                        # x placed into T
            ndp[j] = (ndp[j] + dp[j - x]) % MOD
        dp = ndp
    return dp[k]
