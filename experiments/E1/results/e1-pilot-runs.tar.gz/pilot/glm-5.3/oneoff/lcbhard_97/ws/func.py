from typing import List


def min_cost_to_sort(n: int, permutation: List[int]) -> int:
    """ Given a permutation of integers from 1 to n, find the minimum total cost to sort it in
    ascending order. You can repeatedly swap adjacent elements, where swapping elements at
    positions i and i+1 (1-indexed) costs i.

    Args:
        n: The length of the permutation
        permutation: A list of integers from 1 to n in some order

    Returns:
        The minimum total cost required to sort the permutation in ascending order

    >>> min_cost_to_sort(3, [3, 2, 1])
    4
    >>> min_cost_to_sort(5, [2, 4, 1, 3, 5])
    6
    >>> min_cost_to_sort(2, [1, 2])
    0
    """
    a = list(permutation)
    total = 0

    # Sweep from the left.  Whenever the element at position i is greater than the one
    # immediately after it, that pair is the leftmost inversion in the array, and
    # resolving it immediately is optimal: the prefix a[0..i-1] is already sorted, so the
    # only way to fix the pair is for the two elements to cross each other, and doing it
    # now is at least as cheap as doing it later (elements only get shuffled rightwards --
    # i.e. into more expensive slots -- while other inversions are resolved).  Each swap
    # costs i+1 here because i is the 0-indexed position of the left element of the pair.
    i = 0
    while i < n - 1:
        if a[i] > a[i + 1]:
            a[i], a[i + 1] = a[i + 1], a[i]
            total += i + 1
            # The element that just arrived at slot i may now be smaller than its left
            # neighbour, so step back one slot to re-examine that pair first.
            if i > 0:
                i -= 1
        else:
            i += 1

    return total