import sys
from functools import lru_cache

MOD = 998244353

def brute(W, H, L, R, D, U):
    def blocked(x, y):
        return 0 <= x <= W and 0 <= y <= H and (x < L or x > R or y < D or y > U)

    pts = [(x, y) for x in range(W + 1) for y in range(H + 1) if blocked(x, y)]
    idx = {p: i for i, p in enumerate(pts)}
    g = [0] * len(pts)
    for (x, y), i in idx.items():
        m = 0
        for dx, dy in ((1, 0), (0, 1)):
            q = (x + dx, y + dy)
            if q in idx:
                m |= 1 << idx[q]
        g[i] = m
    cnt = [0] * len(pts)
    for i in range(len(pts) - 1, -1, -1):
        c = 1
        m = g[i]
        while m:
            b = m & -m
            j = b.bit_length() - 1
            c += cnt[j]
            m ^= b
        cnt[i] = c
    return sum(cnt) % MOD

if __name__ == "__main__":
    print(brute(4, 3, 1, 2, 2, 3))       # doc: 192
    print(brute(10, 12, 4, 6, 8, 11))    # doc: 4519189
    print(brute(3, 2, 0, 0, 2, 2))       # test: 93
