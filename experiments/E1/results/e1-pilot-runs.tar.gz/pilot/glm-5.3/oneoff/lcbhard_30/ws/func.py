from functools import lru_cache

MOD = 10 ** 9 + 7


def _digit_sum_count_up_to(n_str: str, lo: int, hi: int) -> int:
    """Count integers x with 0 <= x <= int(n_str) and lo <= digit_sum(x) <= hi.

    Standard digit DP over the decimal representation of n_str.
    The result is returned modulo MOD.
    """
    digits = [int(c) for c in n_str]

    @lru_cache(maxsize=None)
    def dp(pos: int, s: int, tight: bool) -> int:
        # Prune: the running digit sum can only grow.
        if s > hi:
            return 0
        if pos == len(digits):
            return 1 if s >= lo else 0
        limit = digits[pos] if tight else 9
        total = 0
        for d in range(limit + 1):
            total += dp(pos + 1, s + d, tight and d == limit)
        return total % MOD

    return dp(0, 0, True)


def _decrement(num_str: str) -> str:
    """Return the numeric string for int(num_str) - 1 (num_str represents >= 1)."""
    digits = list(num_str)
    i = len(digits) - 1
    while digits[i] == '0':
        digits[i] = '9'
        i -= 1
    digits[i] = str(int(digits[i]) - 1)
    result = ''.join(digits).lstrip('0')
    return result if result else '0'


def count_good_integers(num1: str, num2: str, min_sum: int, max_sum: int) -> int:
    """ Count the number of integers x such that num1 <= x <= num2 and 
    min_sum <= digit_sum(x) <= max_sum, where digit_sum(x) is the sum of digits of x.
    
    Return the count modulo 10^9 + 7.
    
    Args:
        num1: A numeric string representing the lower bound (1 <= num1 <= 10^22)
        num2: A numeric string representing the upper bound (num1 <= num2 <= 10^22)
        min_sum: The minimum allowed digit sum (1 <= min_sum <= 400)
        max_sum: The maximum allowed digit sum (min_sum <= max_sum <= 400)
    
    Returns:
        The number of good integers modulo 10^9 + 7
    
    >>> count_good_integers("1", "12", 1, 8)
    11
    >>> count_good_integers("1", "5", 1, 5)
    5
    """
    upper = _digit_sum_count_up_to(num2, min_sum, max_sum)
    lower = _digit_sum_count_up_to(_decrement(num1), min_sum, max_sum)
    return (upper - lower) % MOD
