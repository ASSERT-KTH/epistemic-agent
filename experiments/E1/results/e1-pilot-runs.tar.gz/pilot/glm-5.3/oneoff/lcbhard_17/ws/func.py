def sum_of_scores(n: int, m: int) -> int:
    """ Calculate the sum of scores of all good sequences modulo 998244353.

    A good sequence is an integer sequence of length between 1 and n (inclusive),
    where each element is between 1 and m (inclusive).

    The score of a good sequence is the number of positive divisors of X,
    where X is the product of all elements in the sequence.

    The function computes the sum of scores of all possible good sequences.
    There are sum(m^k for k in range(1, n+1)) such sequences in total.

    Args:
        n: Maximum length of sequences (1 <= n <= 10^18)
        m: Maximum value of elements (1 <= m <= 16)

    Returns:
        The sum of all scores modulo 998244353

    >>> sum_of_scores(1, 7)
    16
    >>> sum_of_scores(3, 11)
    16095
    >>> sum_of_scores(81131, 14)
    182955659
    """
    MOD = 998244353

    # m == 1: every element is 1, so X = 1 and d(X) = 1 for all n sequences.
    if m == 1:
        return n % MOD

    # --- primes up to m (these are the only primes that can divide X) -------
    primes = [p for p in range(2, m + 1) if all(p % q for q in range(2, p))]
    P = len(primes)

    # exponent vector (over `primes`) of every value 1..m
    exps = []
    for v in range(1, m + 1):
        w, ev = v, []
        for p in primes:
            e = 0
            while w % p == 0:
                w //= p
                e += 1
            ev.append(e)
        exps.append(ev)

    # g[mask] = sum_{v=1..m} prod_{p in mask} e_p(v)   (= mixed partial of G at 1)
    g = [0] * (1 << P)
    for mask in range(1 << P):
        tot = 0
        for ev in exps:
            pr = 1
            for i in range(P):
                if mask >> i & 1:
                    pr *= ev[i]
            tot += pr
        g[mask] = tot % MOD

    # ------------------------------------------------------------------------
    # Derivation.
    #
    # For a fixed length l, let G(y) = sum_{v=1..m} prod_p y_p^{e_p(v)}.
    # For a sequence S, mon(S) = prod_p y_p^{a_p} with a_p = sum_i e_p(v_i),
    # and d(X) = prod_p (a_p + 1).  The functional
    #       phi(prod y_p^{a_p}) = prod_p (a_p + 1)
    # equals  [ prod_p (1 + d/dy_p) H ]_{y=1} , because (1+d/dy) y^a |_{y=1} = a+1.
    # Hence the length-l total is
    #       u_l = phi(G^l)
    #           = sum_{T subseteq primes} [ prod_{p in T} d_p G^l ]_{y=1}
    # and by the multivariate Faà di Bruno rule for the univariate outer
    # function t -> t^l:
    #       [ prod_{p in T} d_p G^l ](1)
    #         = sum_{pi partition of T} (l)_{fall |pi|} * m^{l-|pi|}
    #                       * prod_{B in pi} [ prod_{p in B} d_p G ](1)
    # with [ prod_{p in B} d_p G ](1) = g_B.  Grouping by k = |pi|:
    #       u_l = sum_{k=0..P} h_k * (l)_{fall k} * m^{l-k},
    # where h_k sums prod g_B over all partial set partitions of the primes
    # having exactly k blocks (h_0 = 1).
    #
    # Since sum_{l=1..n} (l)_{fall k} x^l = x^k * F^{(k)}(x) with
    # F(x) = sum_{l=1..n} x^l = (x^{n+1} - x)/(x - 1), the answer is
    #       answer = sum_k h_k * F^{(k)}(m)   (mod 998244353),
    # which is computable in O(P^2) plus a handful of modular powers,
    # independent of the size of n.
    # ------------------------------------------------------------------------

    h = [0] * (P + 1)

    def rec(i: int, blocks: tuple) -> None:
        if i == P:
            pr = 1
            for b in blocks:
                pr = pr * g[b] % MOD
            h[len(blocks)] = (h[len(blocks)] + pr) % MOD
            return
        rec(i + 1, blocks)                       # prime i unused
        rec(i + 1, blocks + (1 << i,))           # prime i opens a new block
        for j in range(len(blocks)):             # prime i joins existing block j
            rec(i + 1, blocks[:j] + (blocks[j] | (1 << i),) + blocks[j + 1:])

    rec(0, ())

    # --- Taylor coefficients of F at a = m, order 0..P -----------------------
    # F(x) = G0(x) * H0(x),  G0(x) = x^{N} - x,  H0(x) = 1/(x-1),  N = n+1.
    a = m % MOD
    N = n + 1

    c = [0] * (P + 1)          # Taylor coefficients of G0 at a
    c[0] = (pow(a, N, MOD) - a) % MOD
    if P >= 1:
        c[1] = (N % MOD * pow(a, N - 1, MOD) - 1) % MOD
    for i in range(2, P + 1):
        if i > N:
            c[i] = 0
            continue
        num = 1
        for j in range(i):
            num = num * ((N - j) % MOD) % MOD
        den = 1
        for j in range(2, i + 1):
            den = den * j % MOD
        c[i] = num * pow(den, MOD - 2, MOD) % MOD * pow(a, N - i, MOD) % MOD

    ip = pow(a - 1, MOD - 2, MOD)
    t = []                      # Taylor coefficients of H0 at a: (-1)^j/(a-1)^{j+1}
    for j in range(P + 1):
        t.append(pow(MOD - ip, j, MOD) * ip % MOD)

    ans = 0
    fact = 1
    for k in range(P + 1):
        if k:
            fact = fact * k % MOD
        f_k = sum(c[i] * t[k - i] for i in range(k + 1)) % MOD
        ans = (ans + h[k] * fact % MOD * f_k) % MOD

    return ans % MOD
