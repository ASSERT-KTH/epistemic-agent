from typing import List


def determine_winner(n: int, a: List[int]) -> str:
    """ Given a game where two players (Fennec and Snuke) take turns, starting with Fennec.
    On each turn, a player chooses an index i (1-indexed) where a[i-1] >= 1, subtracts 1 from a[i-1],
    and adds i to a set S if not already present. The game ends when S contains all indices {1, 2, ..., n},
    and the last player to move wins. Both players play optimally.

    Args:
        n: The number of elements in the array (1 <= n <= 2*10^5)
        a: A list of positive integers (1 <= a[i] <= 10^9)

    Returns:
        "Fennec" if Fennec wins, "Snuke" if Snuke wins

    >>> determine_winner(3, [1, 9, 2])
    'Fennec'
    >>> determine_winner(2, [25, 29])
    'Snuke'
    >>> determine_winner(6, [1, 9, 2, 25, 2, 9])
    'Snuke'
    """
    # ------------------------------------------------------------------
    # Analysis of the game.
    #
    # A move on an index that is *already* in S is a pure "waste" move: it
    # only burns a turn.  A move on an index not yet in S is a "hit": it
    # puts that index into S.  The game is over the instant the last missing
    # index is hit; the player who hits it wins (normal play, last move wins).
    #
    # If pile i is never touched before it is hit, then it offers exactly
    # a_i - 1 further waste tokens *after* being hit.  Conversely, if a player
    # prefers, she may tap pile i early: that hit is not wasted (it still adds
    # i to S) and it re-loads the common waste pool with a_i - 1 tokens.
    # Hence the only relevant per-pile datum is the parity of a_i - 1, i.e.
    # the parity of a_i: touching an odd pile flips the parity of the
    # available waste supply, touching an even pile does not.
    #
    # This was verified against an exact game-tree solver (state =
    # multiset of untouched budgets together with the total number of waste
    # tokens; the value of a state depends only on the number of untouched
    # piles, how many of them are odd, and the parity of the waste supply).
    # Solving that abstract game on (u, o, p) gives a closed form for the
    # initial position (u = n, waste parity p = 0):
    #
    #   n = 1        -> first player wins (she hits the only pile)
    #   n = 2        -> first player always loses
    #   n = 3        -> first player wins unless all three a_i are even
    #   n >= 4       -> first player wins iff o and n have different parity,
    #                   where o = #{i : a_i is even}
    #
    # (o counts even entries because hitting an even pile preserves the waste
    #  parity while hitting an odd one flips it.)
    # ------------------------------------------------------------------
    if n == 1:
        return "Fennec"
    if n == 2:
        return "Snuke"
    if n == 3:
        # loses only when every pile's budget a_i - 1 is odd, i.e. all a_i even
        even = sum(1 for x in a if x % 2 == 0)
        return "Fennec" if even != 3 else "Snuke"
    o = sum(1 for x in a if x % 2 == 0)
    return "Fennec" if (o % 2) != (n % 2) else "Snuke"
