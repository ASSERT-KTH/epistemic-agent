from math import gcd
from typing import List

MOD = 10 ** 9 + 7
MAX_VAL = 200


def _mobius_sieve(limit: int) -> List[int]:
    """Mobius function values for 1..limit via a linear sieve."""
    mu = [0] * (limit + 1)
    mu[1] = 1
    primes = []
    is_comp = [False] * (limit + 1)
    for i in range(2, limit + 1):
        if not is_comp[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            if i * p > limit:
                break
            is_comp[i * p] = True
            if i % p == 0:
                mu[i * p] = 0
                break
            mu[i * p] = -mu[i]
    return mu


def count_subsequence_pairs(nums: List[int]) -> int:
    """ Find the number of pairs of non-empty subsequences (seq1, seq2) of nums that satisfy:
    1. The subsequences seq1 and seq2 are disjoint (no index of nums is common between them)
    2. The GCD of the elements of seq1 is equal to the GCD of the elements of seq2
    
    Return the total number of such pairs modulo 10^9 + 7.
    
    Args:
        nums: An integer array where 1 <= len(nums) <= 200 and 1 <= nums[i] <= 200
    
    Returns:
        The number of valid subsequence pairs modulo 10^9 + 7
    
    >>> count_subsequence_pairs([1, 2, 3, 4])
    10
    >>> count_subsequence_pairs([10, 20, 30])
    2
    >>> count_subsequence_pairs([1, 1, 1, 1])
    50
    """
    n = len(nums)
    mu = _mobius_sieve(MAX_VAL)

    # cnt[d] = number of indices i with d | nums[i].
    cnt = [0] * (MAX_VAL + 1)
    for v in nums:
        d = 1
        while d * d <= v:
            if v % d == 0:
                cnt[d] += 1
                if d * d != v:
                    cnt[v // d] += 1
            d += 1

    pow2 = [1] * (n + 1)
    pow3 = [1] * (n + 1)
    for i in range(1, n + 1):
        pow2[i] = pow2[i - 1] * 2 % MOD
        pow3[i] = pow3[i - 1] * 3 % MOD

    def count_both(m1: int, m2: int) -> int:
        """Number of ordered disjoint non-empty pairs (A, B) with m1 | gcd(A)
        and m2 | gcd(B).  Elements divisible by both m1 and m2 (i.e. by their
        lcm) may go to A, B or neither; the others have only two options."""
        l = m1 * m2 // gcd(m1, m2)
        x = cnt[l] if l <= MAX_VAL else 0
        y = cnt[m1] - x
        z = cnt[m2] - x
        # 3^x * 2^y * 2^z total assignments, minus those with A or B empty
        # (the intersection "both empty" is the single all-neither assignment).
        return (pow3[x] * pow2[y + z] - pow2[x + z] - pow2[x + y] + 1) % MOD

    # R(d1, d2) = number of ordered disjoint non-empty pairs with gcd(A) == d1
    # and gcd(B) == d2.  Since count_both(m1, m2) sums R(d1, d2) over all
    # multiples d1 of m1 and d2 of m2, two-dimensional Mobius inversion gives
    #     R(d1, d2) = sum_{k1, k2} mu(k1) * mu(k2) * count_both(d1*k1, d2*k2)
    # The answer is the diagonal sum over d1 == d2.
    total = 0
    for d in range(1, MAX_VAL + 1):
        limit = MAX_VAL // d
        acc = 0
        for k1 in range(1, limit + 1):
            if mu[k1] == 0:
                continue
            dk1 = d * k1
            row = 0
            for k2 in range(1, limit + 1):
                if mu[k2] == 0:
                    continue
                row += mu[k2] * count_both(dk1, d * k2)
            acc += mu[k1] * row
        total = (total + acc) % MOD
    return total % MOD
