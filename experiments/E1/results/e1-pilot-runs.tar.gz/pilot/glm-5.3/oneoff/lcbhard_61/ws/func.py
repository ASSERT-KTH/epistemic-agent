from typing import List, Tuple


def min_team_switches(people: List[Tuple[int, int]]) -> int:
    """ Given a list of people where each person is represented as (team_number, strength),
    determine the minimum number of people who need to switch teams so that all three teams
    have equal total strength. Teams are numbered 1, 2, and 3.
    
    Each person belongs to exactly one team and has a strength value. The strength of a team
    is the sum of strengths of all its members. Return -1 if it's impossible to make all
    teams have equal strength.
    
    Args:
        people: List of tuples (team_number, strength) where team_number is in {1, 2, 3}
                and strength is a positive integer.
    
    Returns:
        The minimum number of people who need to switch teams, or -1 if impossible.
    
    >>> min_team_switches([(1, 2), (2, 5), (1, 5), (3, 3), (1, 3), (3, 6)])
    2
    >>> min_team_switches([(1, 1), (1, 2), (2, 3), (3, 4)])
    -1
    >>> min_team_switches([(1, 1), (2, 1), (3, 1)])
    0
    """
    if not people:
        return 0

    total = sum(strength for _, strength in people)
    if total % 3 != 0:
        return -1
    target = total // 3

    # Dynamic programming over people: state is (strength already placed on
    # team 1, strength already placed on team 2); the strength on team 3 is
    # implied by what is left.  For each state we keep the minimum number of
    # switches needed to reach it.
    INF = float("inf")
    dp = {(0, 0): 0}
    for team, strength in people:
        home = team - 1  # index of the person's original team
        next_dp = {}
        for (s1, s2), cost in dp.items():
            for idx, state in enumerate(
                ((s1 + strength, s2), (s1, s2 + strength), (s1, s2))
            ):
                if idx == 0 and state[0] > target:
                    continue  # team 1 would overshoot
                if idx == 1 and state[1] > target:
                    continue  # team 2 would overshoot
                new_cost = cost if idx == home else cost + 1
                if new_cost < next_dp.get(state, INF):
                    next_dp[state] = new_cost
        dp = next_dp

    return dp.get((target, target), -1)