from typing import List, Tuple


def min_sensor_cost(n: int, sections: List[int], sensor1: Tuple[int, int, int], sensor2: Tuple[int, int, int]) -> int:
    """ Given N sections to monitor on a conveyor belt, find the minimum cost to monitor all sections using two types of sensors.

    Each section has a length in meters that needs to be monitored. There are two types of sensors available:
    - Type 1: Can monitor L1 meters, costs C1 per sensor, and you can use at most K1 sensors
    - Type 2: Can monitor L2 meters, costs C2 per sensor, and you can use at most K2 sensors

    Sensors can overlap and can monitor more than the required length. For example, to monitor a 5-meter section,
    you could use one 4-meter sensor and one 2-meter sensor (total coverage: 6 meters).

    Args:
        n: Number of sections to monitor (1 <= n <= 100)
        sections: List of section lengths D_i in meters (1 <= D_i <= 10^5)
        sensor1: Tuple (L1, C1, K1) - length, cost, and max count for type 1 sensors
        sensor2: Tuple (L2, C2, K2) - length, cost, and max count for type 2 sensors

    Returns:
        The minimum total cost to monitor all sections, or -1 if impossible.

    >>> min_sensor_cost(3, [3, 5, 10], (4, 3, 3), (2, 2, 6))
    17
    >>> min_sensor_cost(3, [3, 5, 10], (4, 3, 3), (2, 2, 3))
    -1
    >>> min_sensor_cost(2, [4, 8], (3, 1, 100), (4, 10000, 100))
    5
    """
    L1, C1, K1 = sensor1
    L2, C2, K2 = sensor2

    sections = sections[:n]

    # More type-1 sensors than needed to cover every section on its own are
    # useless, so cap the tracked total.
    max_needed = sum(-(-d // L1) for d in sections)
    K1 = min(K1, max_needed)

    INF = float('inf')
    # dp[a] = minimum total number of type-2 sensors needed overall when the
    # sections together use exactly `a` type-1 sensors (a <= K1).
    dp = [0] + [INF] * K1

    for D in sections:
        amax = min(K1, -(-D // L1))
        # For every count k of type-1 sensors on this section, the cheapest
        # completion is the minimal number of type-2 sensors:
        #   b(k) = ceil(max(0, D - L1*k) / L2)
        # Options with b(k) > K2 can never appear in a feasible plan.
        options = []
        for k in range(amax + 1):
            remaining = D - L1 * k
            b = 0 if remaining <= 0 else -(-remaining // L2)
            if b <= K2:
                options.append((k, b))
        if not options:
            return -1

        # b(k) is non-increasing in k, so equal b values are consecutive runs;
        # within a run only the smallest k matters (same b, fewer sensors).
        pruned = []
        prev_b = None
        for k, b in options:
            if b != prev_b:
                pruned.append((k, b))
                prev_b = b

        ndp = [INF] * (K1 + 1)
        for k, b in pruned:
            # using k type-1 and b type-2 sensors on this section
            shifted = [x + b for x in dp[:K1 + 1 - k]]
            target = ndp[k:]
            ndp[k:] = [t if t <= s else s for t, s in zip(target, shifted)]
        dp = ndp

    best = -1
    for a in range(K1 + 1):
        if dp[a] <= K2:
            cost = C1 * a + C2 * dp[a]
            if best == -1 or cost < best:
                best = cost
    return best
