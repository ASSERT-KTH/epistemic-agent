from typing import List, Tuple


def max_dishes_eaten(n: int, x: int, y: int, dishes: List[Tuple[int, int]]) -> int:
    """ Given n dishes where each dish has sweetness and saltiness values, find the maximum
    number of dishes that can be eaten when arranged optimally. Dishes are eaten in order,
    but eating stops if the total sweetness exceeds x or total saltiness exceeds y.

    Args:
        n: Number of dishes (1 <= n <= 80)
        x: Maximum allowed total sweetness (1 <= x <= 10000)
        y: Maximum allowed total saltiness (1 <= y <= 10000)
        dishes: List of tuples (sweetness, saltiness) for each dish, where both values are between 1 and 10000

    Returns:
        Maximum number of dishes that can be eaten with optimal arrangement

    >>> max_dishes_eaten(4, 8, 4, [(1, 5), (3, 2), (4, 1), (5, 3)])
    3
    >>> max_dishes_eaten(2, 1, 1, [(3, 2), (3, 2)])
    1
    >>> max_dishes_eaten(2, 100, 100, [(3, 2), (3, 2)])
    2
    """
    # Semantics (derived from the docstring examples):
    #   * We may order the dishes however we like and eat them one by one.
    #   * A dish is always consumed (it counts as eaten); if consuming it pushes the
    #     running total sweetness above x or the running total saltiness above y, eating
    #     stops immediately afterwards.  (This is what makes
    #     max_dishes_eaten(2, 1, 1, [(3, 2), (3, 2)]) == 1 rather than 0.)
    #   * Therefore the answer is: M + 1, where M is the largest number of dishes whose
    #     combined sweetness is <= x AND combined saltiness is <= y -- capped at n, since
    #     if every dish fits inside the budgets nothing forces us to stop.
    #
    # M is computed exactly with a Pareto-frontier dynamic program:
    #   levels[k] = set of Pareto-minimal (sweetness, saltiness) totals over all
    #               k-subsets of dishes that stay inside both budgets.
    # Because both coordinates only ever grow (every value is >= 1), a state that is
    # dominated by another state of the same cardinality can be discarded safely, and any
    # state already outside a budget can be discarded immediately.

    # 0/1 knapsack over cardinality, dishes in the outer loop so each dish is used once.
    levels = [set() for _ in range(n + 1)]
    levels[0].add((0, 0))

    for a, b in dishes:
        for k in range(n - 1, -1, -1):
            source = levels[k]
            if not source:
                continue
            target = levels[k + 1]
            for s, t in source:
                ns, nt = s + a, t + b
                if ns <= x and nt <= y:
                    target.add((ns, nt))
        # Prune dominated states so the frontiers stay small.
        for k in range(1, n + 1):
            level = levels[k]
            if len(level) > 1:
                kept = []
                best_t = None
                for s, t in sorted(level):
                    if best_t is None or t < best_t:
                        kept.append((s, t))
                        best_t = t
                levels[k] = set(kept)

    # NOTE ON THE DISPUTED TEST CASE
    # -------------------------------
    # test.py's first assertion expects 4 for (4, 8, 4, [(1,5),(3,2),(4,1),(5,3)]),
    # while the docstring for the *same input* documents 3, so the two cannot both hold.
    # 4 is also arithmetically impossible under any reading of the stopping rule: all four
    # dishes total sweetness 13 (> x=8) and saltiness 11 (> y=4) simultaneously, so every
    # ordering is out of budget before the 4th dish (verified by enumerating all 24
    # orderings). The only reading that yields 4 (violation = sweet>x OR salt>y on the
    # *subset* total, breaking dish counted) breaks assertion #4, which expects 3.
    # Hence assertion #1 is treated as a bug in the test, not in this implementation;
    # assertions #2..#10 all pass.

    # Largest cardinality that still has a feasible state.
    m = 0
    for k in range(n, -1, -1):
        if levels[k]:
            m = k
            break

    return m if m == n else m + 1
